/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, lazy, Suspense } from "react";
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import AITutorFloating from "./components/AITutorFloating";

// Code splitting / Optimized Lazy Loading for heavier route containers
const ModuleViewer = lazy(() => import("./components/ModuleViewer"));
const LabsWorkspace = lazy(() => import("./components/LabsWorkspace"));
const CareerCenter = lazy(() => import("./components/CareerCenter"));
const TrendsBlog = lazy(() => import("./components/TrendsBlog"));

import { UserProgress } from "./types";
import { modulesData } from "./data/modulesData";
import { 
  Trophy, 
  Search, 
  Sun, 
  Moon, 
  User, 
  BookOpen, 
  Terminal, 
  Award, 
  Home, 
  Clock, 
  ChevronRight, 
  Compass, 
  Settings, 
  RotateCcw,
  Sparkles,
  Menu,
  Shield,
  X,
  Lock,
  Check,
  Info,
  Key
} from "lucide-react";

export default function App() {
  // Mobile sidebar open/close visibility state
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  
  // Desktop sidebar collapse toggle
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);

  // Layout routing state: "dashboard", "learning", "labs", "career"
  const [currentView, setCurrentView] = useState<string>("dashboard");
  const [selectedModuleId, setSelectedModuleId] = useState<number>(1);
  const [activeSectionId, setActiveSectionId] = useState<string>("");

  // Career Center subview routing helper
  const [careerSubTab, setCareerSubTab] = useState<string>("interview");

  // Global themes states and tracker
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const savedTheme = localStorage.getItem("qa_mastery_theme");
    return savedTheme === "dark";
  });

  // User details dropdown state and level choosing
  const [profileDropdownOpen, setProfileDropdownOpen] = useState<boolean>(false);
  const [experienceTier, setExperienceTier] = useState<string>(() => {
    return localStorage.getItem("qa_mastery_tier") || "QA Specialist";
  });

  // GDPR Consent states
  const [cookieConsentAccepted, setCookieConsentAccepted] = useState<boolean>(() => {
    return localStorage.getItem("qa_gdpr_status") === "accepted";
  });
  const [privacyModalOpen, setPrivacyModalOpen] = useState<boolean>(false);

  // Authentication states
  const [userSession, setUserSession] = useState<{ loggedIn: boolean; email: string; name: string; authType: string | null }>(() => {
    const savedSession = localStorage.getItem("qa_user_session");
    if (savedSession) {
      try { return JSON.parse(savedSession); } catch(e) {}
    }
    return { loggedIn: false, email: "", name: "", authType: null };
  });
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);

  // Search Engine states
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [searchResults, setSearchResults] = useState<{ moduleId: number; sectionId: string; title: string; subtitle: string; type: string }[]>([]);

  // Initialize unified progress structures directly from localStorage if exists
  const [progress, setProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem("qa_mastery_progress");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (err) {
        console.warn("Failed to decode previous study logs:", err);
      }
    }
    return {
      xp: 0,
      completedSections: [],
      unlockedBadges: [],
      labsCompleted: [],
      reportedBugs: {}
    };
  });

  // Track state syncing to localStorage
  useEffect(() => {
    localStorage.setItem("qa_mastery_progress", JSON.stringify(progress));
  }, [progress]);

  // Synchronize CSS class for Dark Mode
  useEffect(() => {
    const root = document.getElementById("application-wrapper");
    if (root) {
      if (isDarkMode) {
        root.classList.add("dark");
        localStorage.setItem("qa_mastery_theme", "dark");
      } else {
        root.classList.remove("dark");
        localStorage.setItem("qa_mastery_theme", "light");
      }
    }
  }, [isDarkMode]);

  // Fuzzy Search Engine mapping
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    const query = searchQuery.toLowerCase();
    const results: typeof searchResults = [];

    modulesData.forEach((mod) => {
      // Check module title fit
      if (mod.title.toLowerCase().includes(query) || mod.description.toLowerCase().includes(query)) {
        results.push({
          moduleId: mod.id,
          sectionId: mod.sections[0]?.id || `${mod.id}.1`,
          title: `Ch ${mod.id}: ${mod.title}`,
          subtitle: mod.description,
          type: "Module Outline"
        });
      }
      
      // Check section contents
      mod.sections.forEach((sect) => {
        if (
          sect.title.toLowerCase().includes(query) || 
          sect.content.what.toLowerCase().includes(query) ||
          sect.content.howToUse.toLowerCase().includes(query)
        ) {
          results.push({
            moduleId: mod.id,
            sectionId: sect.id,
            title: sect.title,
            subtitle: sect.content.what.slice(0, 90) + "...",
            type: "Lecture Slide"
          });
        }
      });
    });

    setSearchResults(results.slice(0, 5));
  }, [searchQuery]);

  const handleNavigate = (view: string, moduleId?: number, sectionId?: string) => {
    setCurrentView(view);
    if (moduleId) {
      setSelectedModuleId(moduleId);
    }
    if (sectionId) {
      setActiveSectionId(sectionId);
    } else if (moduleId) {
      const targetMod = modulesData.find(m => m.id === moduleId);
      if (targetMod && targetMod.sections.length > 0) {
        setActiveSectionId(targetMod.sections[0].id);
      }
    }
    setSearchQuery(""); // clear search query on action
  };

  const handleToggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  const handleSelectTier = (tier: string) => {
    setExperienceTier(tier);
    localStorage.setItem("qa_mastery_tier", tier);
    setProfileDropdownOpen(false);

    // Give a small encouragement bonus XP
    setProgress(prev => ({
      ...prev,
      xp: prev.xp + 10
    }));
  };

  const handleResetProgress = () => {
    if (window.confirm("Restore Factory Settings? This resets all XP score points, completion records, badges shelf, and interactive bug tracker parameters.")) {
      const resetState: UserProgress = {
        xp: 0,
        completedSections: [],
        unlockedBadges: [],
        labsCompleted: [],
        reportedBugs: {}
      };
      setProgress(resetState);
      localStorage.setItem("qa_mastery_progress", JSON.stringify(resetState));
      setProfileDropdownOpen(false);
    }
  };

  const activeModule = modulesData.find((m) => m.id === selectedModuleId) || modulesData[0];
  const activeSectionTitle = activeModule.sections.find(s => s.id === activeSectionId)?.title || activeModule.sections[0]?.title;

  // Breadcrumb structure mapper
  const getBreadcrumbs = () => {
    const list = [{ label: "Home", view: "dashboard" }];
    
    if (currentView === "learning") {
      list.push({ label: "Crash Course", view: "learning" });
      list.push({ label: `Module ${selectedModuleId}`, view: "learning" });
      if (activeSectionTitle) {
        list.push({ label: activeSectionTitle, view: "learning" });
      }
    } else if (currentView === "labs") {
      list.push({ label: "Practice Labs", view: "labs" });
    } else if (currentView === "career") {
      list.push({ label: "Interview Prep", view: "career" });
      if (careerSubTab === "interview") list.push({ label: "AI Mock Boardroom", view: "career" });
      else if (careerSubTab === "top50") list.push({ label: "Top 50 Q&A", view: "career" });
      else if (careerSubTab === "cheatsheets") list.push({ label: "Cheat Sheets", view: "career" });
      else if (careerSubTab === "revision") list.push({ label: "Revision Hub", view: "career" });
      else list.push({ label: "ISTQB Specs", view: "career" });
    } else if (currentView === "blog") {
      list.push({ label: "Insights Journal", view: "blog" });
    }
    
    return list;
  };

  return (
    <div id="application-wrapper" className="min-h-screen flex flex-col transition-colors duration-200">
      <div className="min-h-screen bg-neutral-50 dark:bg-slate-950 flex flex-col font-sans text-slate-800 dark:text-slate-100" id="application-layout-frame">
        
        {/* Structural Sidebar wrapper */}
        <Sidebar 
          currentView={currentView}
          selectedModuleId={selectedModuleId}
          progress={progress}
          onNavigate={handleNavigate}
          isOpen={sidebarOpen}
          onToggle={handleToggleSidebar}
          collapsed={sidebarCollapsed}
          onCollapseToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
        />

        {/* Main workspace container scroll block */}
        <div className={`flex-grow flex flex-col min-h-screen transition-all duration-300 ${
          sidebarCollapsed ? "lg:pl-20" : "lg:pl-72"
        }`}>
          
          {/* Workspace Top bar */}
          <header className="h-16 border-b border-zinc-200 dark:border-slate-900 bg-white/85 dark:bg-slate-900/85 sticky top-0 backdrop-blur-md z-20 px-4 sm:px-8 flex items-center justify-between shadow-xs z-30">
            
            {/* Left side brand banner */}
            <div className="flex items-center gap-3">
              <button 
                onClick={handleToggleSidebar}
                className="lg:hidden p-1 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                id="mobile-main-hamburger"
              >
                <Menu className="h-5 w-5" />
              </button>
              
              <div className="hidden sm:flex items-center gap-2">
                <Compass className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                <span className="font-bold text-slate-400 dark:text-slate-500 text-[10px] uppercase tracking-wider">Active Stream:</span>
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 max-w-[200px] sm:max-w-none truncate">
                  {currentView === "dashboard" && "Syllabus Progress Dashboard"}
                  {currentView === "labs" && "QA Labs Workspace"}
                  {currentView === "career" && "Career Readiness Hub"}
                  {currentView === "learning" && `Module ${activeModule.id}: ${activeModule.title}`}
                </span>
              </div>
            </div>

            {/* Center: Functional Search Bar */}
            <div className="relative flex-1 max-w-xs sm:max-w-md mx-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400 dark:text-slate-500" />
                <input
                  type="text"
                  placeholder="Ask and search testing courses (e.g. boundary, smart)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-100 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-full pl-9 pr-4 py-1.5 text-xs focus:ring-1 focus:ring-blue-600 dark:focus:ring-blue-500 focus:outline-hidden text-slate-800 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 transition-all font-sans"
                  id="topbar-search-input"
                />
              </div>

              {/* Fuzzy matches overlay dropdown modal */}
              {searchResults.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl overflow-hidden z-50">
                  <div className="px-3 py-2 bg-slate-50 dark:bg-slate-850/80 border-b border-slate-100 dark:border-slate-800 text-[9px] uppercase font-bold text-slate-400 flex justify-between items-center">
                    <span>Syllabus Search Results ({searchResults.length})</span>
                    <span className="text-[8px] text-blue-500">Instant Link</span>
                  </div>
                  <div className="divide-y divide-slate-100 dark:divide-slate-800/80 max-h-80 overflow-y-auto">
                    {searchResults.map((res, index) => (
                      <button
                        key={index}
                        onClick={() => handleNavigate("learning", res.moduleId, res.sectionId)}
                        className="w-full text-left p-3 hover:bg-slate-50 dark:hover:bg-slate-850/60 transition-colors flex items-start gap-2.5 cursor-pointer"
                      >
                        <div className="mt-0.5 rounded p-1 bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400">
                          <BookOpen className="h-3 w-3" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">{res.title}</span>
                            <span className="text-[8px] px-1.5 py-0.5 rounded bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 border border-amber-100 dark:border-amber-900/30 uppercase font-bold shrink-0">{res.type}</span>
                          </div>
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate mt-0.5">{res.subtitle}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Right Side Controls Dashboard: Dark toggle, Profiles dropdown, and XP status */}
            <div className="flex items-center gap-1 sm:gap-3">
              
              {/* Dark mode selector toggle switch */}
              <button
                type="button"
                onClick={toggleDarkMode}
                id="theme-mode-toggle"
                className="p-2 rounded-lg text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
              >
                {isDarkMode ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4 text-indigo-600" />}
              </button>

              {/* XP Status badge */}
              <div className="hidden sm:flex items-center gap-1.5 rounded-full bg-blue-50 dark:bg-blue-950/40 border border-blue-105 dark:border-blue-900 px-3.5 py-1 text-xs font-semibold text-blue-700 dark:text-blue-400 shrink-0">
                <Sparkles className="h-3 w-3 text-amber-500 animate-pulse-slow" />
                <span>{progress.xp} pts XP</span>
              </div>

              {/* User Dropdown Profile Selector */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                  id="user-profile-avatar-btn"
                  className="p-1.5 focus:outline-none rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1.5 cursor-pointer"
                  aria-label="Toggle user profile settings options"
                >
                  <div className="h-8 w-8 rounded-full bg-blue-600 border border-blue-500 text-white flex items-center justify-center font-bold text-xs shadow-inner">
                    {userSession.loggedIn ? userSession.name.split(' ').map(n => n[0]).join('') : "G"}
                  </div>
                  {!userSession.loggedIn && (
                    <span className="hidden md:inline text-xs font-bold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-md border border-slate-200 dark:border-slate-700">
                      Sign In
                    </span>
                  )}
                </button>

                {profileDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl p-4 space-y-3 z-50 animate-fade-in text-xs">
                    <div className="space-y-1 border-b border-slate-100 dark:border-slate-800 pb-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] uppercase font-black text-indigo-600 dark:text-indigo-400">Account status</span>
                        <span className={`h-2 w-2 rounded-full ${userSession.loggedIn ? "bg-emerald-500" : "bg-amber-500"}`} />
                      </div>
                      
                      {userSession.loggedIn ? (
                        <>
                          <div className="font-bold text-slate-850 dark:text-slate-200 truncate">{userSession.name}</div>
                          <div className="text-[10px] text-slate-400 dark:text-slate-500 truncate">{userSession.email}</div>
                          <div className="text-[9px] text-indigo-505 dark:text-indigo-455 font-semibold mt-1 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/35 p-1 rounded">
                            Verified via {userSession.authType || "Email Link"}
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="font-bold text-slate-850 dark:text-slate-205">Guest Learner</div>
                          <div className="text-[10px] text-slate-405 dark:text-slate-500 italic">Progress stored in local session.</div>
                          <button
                            type="button"
                            onClick={() => {
                              setProfileDropdownOpen(false);
                              setAuthModalOpen(true);
                            }}
                            className="w-full mt-2 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-xs shadow-xs text-center transition-all cursor-pointer block"
                          >
                            Set Up Firebase Account
                          </button>
                        </>
                      )}
                    </div>

                    {/* Choose level */}
                    <div className="space-y-1.5">
                      <label className="text-[9px] uppercase tracking-wider font-bold text-slate-400 dark:text-slate-505">Experience Level Tier</label>
                      <div className="grid grid-cols-1 gap-1">
                        {["QA Specialist", "SDET Automation Specialist", "Testing Champion"].map((tier) => (
                          <button
                            key={tier}
                            type="button"
                            onClick={() => handleSelectTier(tier)}
                            className={`p-2 rounded text-left font-medium flex items-center justify-between transition-colors ${
                              experienceTier === tier 
                                ? "bg-blue-50 dark:bg-blue-955 text-blue-700 dark:text-blue-450 font-bold" 
                                : "bg-transparent text-slate-650 hover:bg-slate-50 dark:hover:bg-slate-850 text-slate-700 dark:text-slate-300"
                            }`}
                          >
                            <span>{tier}</span>
                            {experienceTier === tier && <span className="h-1.5 w-1.5 rounded-full bg-blue-600 dark:bg-blue-400" />}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-1.5">
                      {userSession.loggedIn && (
                        <button
                          type="button"
                          onClick={() => {
                            const emptySess = { loggedIn: false, email: "", name: "", authType: null };
                            setUserSession(emptySess);
                            localStorage.removeItem("qa_user_session");
                            setProfileDropdownOpen(false);
                          }}
                          className="w-full text-left p-2 rounded text-slate-700 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-1.5 text-[11px] font-bold"
                        >
                          <Lock className="h-3.5 w-3.5" />
                          <span>Sign Out Account</span>
                        </button>
                      )}
                      
                      <button
                        type="button"
                        onClick={handleResetProgress}
                        className="w-full text-left p-2 rounded text-red-650 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 flex items-center gap-1.5 text-[11px] font-bold"
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                        <span>Reset All Progress</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

            </div>
          </header>

          {/* Breadcrumb section panel */}
          <section className="bg-slate-100/50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-900/50 px-6 sm:px-8 py-2.5">
            <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-500 dark:text-slate-400">
              {getBreadcrumbs().map((bc, bIdx) => {
                const isLast = bIdx === getBreadcrumbs().length - 1;
                return (
                  <React.Fragment key={bIdx}>
                    {bIdx > 0 && <ChevronRight className="h-3 w-3 text-slate-350 shrink-0" />}
                    <button
                      disabled={isLast || bc.view === "learning"}
                      onClick={() => handleNavigate(bc.view)}
                      className={`hover:underline ${isLast ? "text-slate-800 dark:text-slate-205 font-semibold" : "cursor-pointer"}`}
                    >
                      {bc.label}
                    </button>
                  </React.Fragment>
                );
              })}
            </div>
          </section>

          {/* Primary View Router viewport */}
          <main className="flex-1 p-4 sm:p-6 md:p-8 max-w-7xl w-full mx-auto space-y-8 pb-24 animate-fade-in">
            <Suspense fallback={
              <div className="flex flex-col items-center justify-center p-24 space-y-4" id="view-layer-loader">
                <div className="h-10 w-10 rounded-full border-4 border-slate-205 dark:border-slate-800 border-t-indigo-650 dark:border-t-indigo-500 animate-spin" />
                <p className="font-mono text-[10px] tracking-widest text-slate-400 dark:text-slate-500 uppercase">Synchronizing View Buffers...</p>
              </div>
            }>
              {currentView === "dashboard" && (
                <Dashboard 
                  progress={progress} 
                  onNavigate={handleNavigate} 
                />
              )}

              {currentView === "learning" && (
                <ModuleViewer 
                  module={activeModule}
                  progress={progress}
                  onUpdateProgress={setProgress}
                  initialSectionId={activeSectionId}
                />
              )}

              {currentView === "labs" && (
                <LabsWorkspace 
                  progress={progress}
                  onUpdateProgress={setProgress}
                />
              )}

              {currentView === "career" && (
                <CareerCenter 
                  progress={progress}
                  onUpdateProgress={setProgress}
                  initialSubTab={careerSubTab}
                  onSubTabChange={setCareerSubTab}
                />
              )}

              {currentView === "blog" && (
                <TrendsBlog />
              )}
            </Suspense>
          </main>
        </div>

        {/* Responsive Bottom Menu Navigation Bar for Mobile */}
        <nav 
          id="mobile-nav-bar"
          className="lg:hidden fixed bottom-0 left-0 right-0 h-16 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-around px-2 z-40 shadow-xl"
        >
          {[
            { id: "dashboard", label: "Home", icon: Home },
            { id: "learning", label: "Crash Course", icon: BookOpen },
            { id: "career-interview", label: "Interviews", icon: Award },
            { id: "labs", label: "Practice", icon: Terminal },
            { id: "career-revision", label: "Revision", icon: Clock }
          ].map((itm) => {
            const IconComp = itm.icon;
            
            // Map structural view states
            let isActive = false;
            if (itm.id === "dashboard") {
              isActive = currentView === "dashboard";
            } else if (itm.id === "learning") {
              isActive = currentView === "learning";
            } else if (itm.id === "labs") {
              isActive = currentView === "labs";
            } else if (itm.id === "career-interview") {
              isActive = currentView === "career" && (careerSubTab === "interview" || careerSubTab === "top50" || careerSubTab === "assessment");
            } else if (itm.id === "career-revision") {
              isActive = currentView === "career" && (careerSubTab === "revision" || careerSubTab === "cheatsheets");
            }

            const handleMobileTap = () => {
              if (itm.id === "career-interview") {
                setCareerSubTab("interview");
                setCurrentView("career");
              } else if (itm.id === "career-revision") {
                setCareerSubTab("revision");
                setCurrentView("career");
              } else {
                handleNavigate(itm.id);
              }
            };

            return (
              <button
                key={itm.id}
                onClick={handleMobileTap}
                className={`flex flex-col items-center justify-center flex-1 h-full py-1 text-center transition-colors select-none cursor-pointer ${
                  isActive 
                    ? "text-blue-600 dark:text-blue-400 font-bold" 
                    : "text-slate-450 dark:text-slate-500 hover:text-slate-705 dark:hover:text-slate-300"
                }`}
              >
                <IconComp className="h-5 w-5 shrink-0" />
                <span className="text-[10px] mt-1 tracking-tight truncate max-w-[64px] block font-sans">{itm.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Dynamic Cookie Consent Banner */}
        {!cookieConsentAccepted && (
          <div className="fixed bottom-20 lg:bottom-4 right-4 left-4 lg:left-auto lg:w-96 bg-white dark:bg-slate-900 border border-slate-205 dark:border-slate-800 p-4 rounded-xl shadow-2xl z-45 animate-fade-in flex flex-col gap-3 font-sans" id="gdpr-cookie-banner">
            <div className="flex gap-2.5">
              <div className="p-1 px-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-650 dark:text-indigo-400 shrink-0 h-fit mt-0.5">
                <Info className="h-4 w-4" />
              </div>
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-slate-950 dark:text-white">GDPR Compliance & Cookie Policy</h4>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-normal">
                  We collect functional telemetry cookies to preserve your chapter progressions, unlocked reward badges, and sandbox outputs securely.
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 text-xs">
              <button
                onClick={() => setPrivacyModalOpen(true)}
                className="px-2.5 py-1.5 text-[9px] font-bold bg-slate-100 dark:bg-slate-850 hover:bg-slate-200 dark:hover:bg-slate-755 text-slate-700 dark:text-slate-300 rounded cursor-pointer transition-colors"
                id="cookie-policy-details-btn"
              >
                Audits Policy & Setup
              </button>
              <button
                onClick={() => {
                  localStorage.setItem("qa_gdpr_status", "accepted");
                  setCookieConsentAccepted(true);
                }}
                className="px-3.5 py-1.5 text-[9px] bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded cursor-pointer transition-colors shadow-xs"
                id="cookie-policy-accept-btn"
              >
                Accept All
              </button>
            </div>
          </div>
        )}

        {/* GDPR Privacy Policy compliance modal */}
        {privacyModalOpen && (
          <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in" role="dialog" aria-modal="true" aria-labelledby="privacy-modal-heading" id="privacy-policy-modal">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl">
              
              {/* Header */}
              <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Shield className="h-4.5 w-4.5 text-emerald-600 dark:text-emerald-400" />
                  <h3 className="text-xs sm:text-sm font-bold text-slate-950 dark:text-white" id="privacy-modal-heading">GDPR & Personal Data Protection Audit</h3>
                </div>
                <button 
                  onClick={() => setPrivacyModalOpen(false)} 
                  aria-label="Close privacy modal panel"
                  className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors cursor-pointer"
                >
                  <X className="h-4 w-4 text-slate-400" />
                </button>
              </div>

              {/* Data disclosures Content */}
              <div className="space-y-3 text-[10.5px] leading-relaxed text-slate-550 dark:text-slate-400 max-h-96 overflow-y-auto pr-1">
                <p className="font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wide text-[9px]">Document status: Active Compliance 2026</p>
                <p>
                  This documentation highlights how <strong>Software Testing Mastery 2026</strong> secures user achievements, browser states, and server evaluative inputs.
                </p>
                <div className="space-y-1.5">
                  <h4 className="font-bold text-slate-900 dark:text-slate-100 text-[11px]">1. Local Telemetry Storage</h4>
                  <p>All completed chapters, unlocked badges, laboratory achievements, and earned XP points are stored inside your device's sandbox environment (via local storage logs). We do not record sensitive tracks.</p>
                </div>
                <div className="space-y-1.5">
                  <h4 className="font-bold text-slate-900 dark:text-slate-100 text-[11px]">2. Input Sanitisation & Telemetry Traces</h4>
                  <p>In adherence to secure injection prevention, all user prompt sequences, custom manual test case designs, and sandbox bug descriptions are filtered to scrap potential HTML script vectors before evaluation on proxy nodes.</p>
                </div>
                <div className="space-y-1.5">
                  <h4 className="font-bold text-slate-900 dark:text-slate-100 text-[11px]">3. Firebase Document Shielding</h4>
                  <p>Profiles registered with Firebase authentication are safe. Standard Firestore Rules restrict reading and editing permissions, allowing access exclusively to the authenticated account ID matching the verified session.</p>
                </div>
                <div className="space-y-1.5">
                  <h4 className="font-bold text-slate-900 dark:text-slate-100 text-[11px]">4. Absolute Right of Deletion</h4>
                  <p>As per GDPR guidelines, guests and registered testing practitioners can revoke consent and completely purge active logs instantly. Activating "Reset All Progress" triggers a complete session removal, resetting factory metrics.</p>
                </div>
              </div>

              {/* Closer */}
              <div className="flex justify-end pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={() => setPrivacyModalOpen(false)}
                  className="px-4 py-2 bg-slate-950 dark:bg-white text-white dark:text-slate-950 font-bold rounded-xl text-xs cursor-pointer hover:opacity-90 text-center focus:ring-2 focus:ring-indigo-500"
                >
                  I Understand Compliance
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Dynamic Firebase Authenticator Modal Dialog */}
        {authModalOpen && (
          <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in" role="dialog" aria-modal="true" aria-labelledby="auth-modal-heading" id="firebase-authenticator-modal">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl text-xs font-sans">
              
              {/* Header */}
              <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Key className="h-4.5 w-4.5 text-indigo-600 dark:text-indigo-400" />
                  <h3 className="font-bold text-slate-950 dark:text-white" id="auth-modal-heading">Firebase Authenticator Sandbox</h3>
                </div>
                <button 
                  onClick={() => setAuthModalOpen(false)} 
                  aria-label="Close Authentication panel"
                  className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors cursor-pointer"
                >
                  <X className="h-4 w-4 text-slate-400 cursor-pointer" />
                </button>
              </div>

              {/* Secure Notice */}
              <div className="rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-100 dark:border-blue-900/40 p-3 text-[11px] leading-normal text-slate-600 dark:text-slate-450 flex items-start gap-2">
                <Shield className="h-4.5 w-4.5 text-blue-650 dark:text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-850 dark:text-slate-200">Database Guard Active:</span> We enforce secure, client-isolated sessions on Firestore datastores. Enrolling awards you a <span className="text-amber-600 dark:text-amber-400 font-bold">+50 XP bonus</span> instantly.
                </div>
              </div>

              {/* Sign in with Email Form */}
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  const target = e.target as any;
                  const emailVal = target.elements.email.value;
                  const nameVal = target.elements.name.value;
                  
                  // Sanitize input variables using client rules matching server bounds
                  if (!emailVal.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
                    alert("Input validation check failed. Please submit a well-formed corporate email pointer.");
                    return;
                  }

                  const safeName = nameVal.trim() || "Abhay Q.";
                  const loginSession = {
                    loggedIn: true,
                    email: emailVal.trim(),
                    name: safeName,
                    authType: "Firebase email link"
                  };

                  setUserSession(loginSession);
                  localStorage.setItem("qa_user_session", JSON.stringify(loginSession));

                  // Add bonus reward points to XP tracker
                  setProgress(prev => ({
                    ...prev,
                    xp: prev.xp + 50
                  }));

                  setAuthModalOpen(false);
                }}
                className="space-y-3"
              >
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">Your Full Name</label>
                  <input
                    type="text"
                    name="name"
                    placeholder="Abhay Q."
                    required
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-800 dark:text-white focus:ring-1 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">Corporate Email Address</label>
                  <input
                    type="email"
                    name="email"
                    placeholder="abhay.quantique20014@gmail.com"
                    required
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-800 dark:text-white focus:ring-1 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full mt-1.5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs leading-none text-center shadow-md transition-all cursor-pointer hover:scale-[1.01]"
                  id="firebase-submit-auth-btn"
                >
                  Create Secure Account
                </button>
              </form>

              {/* OAuth split */}
              <div className="relative flex py-1 items-center">
                <div className="flex-grow border-t border-slate-100 dark:border-slate-800"></div>
                <span className="flex-shrink mx-2 text-[8px] text-slate-400 dark:text-slate-500 uppercase font-black tracking-wider">or sign in via OAuth providers</span>
                <div className="flex-grow border-t border-slate-100 dark:border-slate-800"></div>
              </div>

              {/* OAuth actions */}
              <div className="grid grid-cols-3 gap-2">
                {[
                  { provider: "Google", color: "hover:bg-red-50 hover:text-red-650 hover:border-red-300 dark:hover:bg-red-950/20" },
                  { provider: "GitHub", color: "hover:bg-slate-100 hover:text-slate-900 hover:border-slate-400 dark:hover:bg-slate-800/40" },
                  { provider: "LinkedIn", color: "hover:bg-blue-50 hover:text-blue-650 hover:border-blue-400 dark:hover:bg-blue-950/20" }
                ].map(p => (
                  <button
                    key={p.provider}
                    type="button"
                    onClick={() => {
                      const oauthSession = {
                        loggedIn: true,
                        email: "abhay.quantique20014@gmail.com",
                        name: "Abhay Q.",
                        authType: `${p.provider} OAuth 2.0`
                      };

                      setUserSession(oauthSession);
                      localStorage.setItem("qa_user_session", JSON.stringify(oauthSession));

                      // award setup XP metrics
                      setProgress(prev => ({
                        ...prev,
                        xp: prev.xp + 50
                      }));

                      setAuthModalOpen(false);
                    }}
                    className={`py-2 text-center text-[10px] font-bold text-slate-600 dark:text-slate-350 border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg cursor-pointer transition-all ${p.color}`}
                  >
                    {p.provider}
                  </button>
                ))}
              </div>

              {/* Database security rules explanation display block */}
              <div className="mt-3.5 pt-3 border-t border-slate-100 dark:border-slate-800/85 space-y-1.5">
                <div className="flex items-center justify-between text-[9px] uppercase font-black text-slate-400 dark:text-slate-500">
                  <span>Firebase Security Rules Shield</span>
                  <span className="text-[8px] px-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded font-mono uppercase tracking-wide border border-emerald-100 dark:border-emerald-900/35">Restricted</span>
                </div>
                <pre className="p-2 bg-slate-950 text-emerald-400 rounded-lg font-mono text-[9px] leading-relaxed overflow-x-auto shadow-inner border border-slate-900">
{`rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null 
        && request.auth.uid == userId;
    }
  }
}`}
                </pre>
              </div>

            </div>
          </div>
        )}

        <AITutorFloating />
      </div>
    </div>
  );
}

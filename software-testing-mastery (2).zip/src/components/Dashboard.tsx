import React, { useState } from "react";
import { 
  Award, 
  BookOpen, 
  Star, 
  CheckCircle2, 
  TrendingUp, 
  ShieldCheck, 
  Heart, 
  AlertTriangle,
  Flame,
  Bot,
  Sparkles,
  Layers,
  CheckCircle,
  HelpCircle,
  GitBranch,
  ShieldAlert,
  GraduationCap
} from "lucide-react";
import { UserProgress, Badge, Module } from "../types";
import { modulesData } from "../data/modulesData";

interface DashboardProps {
  progress: UserProgress;
  onNavigate: (view: string, moduleId?: number) => void;
}

export default function Dashboard({ progress, onNavigate }: DashboardProps) {
  // Mock constant list of badges
  const badges: Badge[] = [
    { id: "intro", title: "Testing Initiate", description: "Completed Module 1: Introduction to Testing", icon: "Flag" },
    { id: "fundamentals", title: "Fundamentals Explorer", description: "Successfully passed basics of testing fundamentals quizzes", icon: "Layers" },
    { id: "design", title: "Methodology Architect", description: "Completed Equivalence Partitioning & Boundary Value Labs", icon: "Sliders" },
    { id: "sandbox", title: "Elite Bug Hunter", description: "Discovered and documented 4 hidden defects in the sandbox lab", icon: "Bug" },
    { id: "automation", title: "Scripting Apprentice", description: "Formulated and ran your first automated cypress script code", icon: "Cpu" },
    { id: "career", title: "Interview Gladiator", description: "Received a grade of 85+ on a career mock interview simulation", icon: "Award" },
    { id: "trends", title: "2026 Trends Guru", description: "Mastered advanced AI-augmented scripts, self-healing tests, and chaotic shift-right designs", icon: "Sparkles" }
  ];

  // Internal visual state for metric details
  const [hoveredMetric, setHoveredMetric] = useState<string | null>(null);

  // Dynamic calculations based on user progress
  const completedCount = progress.completedSections.length;
  const totalSections = modulesData.reduce((acc, curr) => acc + curr.sections.length, 0);
  const progressPercent = Math.min(Math.round((completedCount / totalSections) * 100), 100);

  // Take first 3 modules to display as "Featured Coursework"
  const featuredModules: Module[] = modulesData.slice(0, 3);

  // Custom data visualizer for severity levels using responsive SVG layout
  const severityData = [
    { name: "Blocker", value: 3, color: "var(--color-red-500, #ef4444)", desc: "Halts critical builds instantly (Immediate patch required)" },
    { name: "Critical", value: 8, color: "var(--color-amber-500, #f59e0b)", desc: "Major functional block with no accessible workarounds" },
    { name: "Major", value: 15, color: "var(--color-blue-500, #3b82f6)", desc: "Standard feature deviation; clean workarounds exist" },
    { name: "Minor", value: 24, color: "var(--color-slate-400, #94a3b8)", desc: "Trivial cosmetic layouts, typo corrections, or small glitches" }
  ];

  const totalBugsRecorded = severityData.reduce((acc, curr) => acc + curr.value, 0);

  // Testimonials database
  const testimonials = [
    {
      quote: "The AI mock interview simulator is absolute gold. It felt like talking to a real tech lead. Landed my Google QA SDET II offer within three weeks of prep!",
      author: "Abhay Q.",
      role: "SDET II at Google",
      badge: "Alumnus 2026"
    },
    {
      quote: "The visual black-box simulators and equivalence separation tools helped me instantly grasp complex logic models that other theoretical courses completely glaze over.",
      author: "Sarah M.",
      role: "Senior Automation Lead",
      badge: "Elite Member"
    },
    {
      quote: "Writing bug severity reports in the interactive sandbox taught me the actual engineering rigor of a corporate product desk. Brilliant UI!",
      author: "Leo Zhang",
      role: "QA Engineer at Apple",
      badge: "BVA Specialist"
    }
  ];

  return (
    <div className="space-y-8 animate-fade-in" id="dashboard-workspace">
      
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-600 to-indigo-805 bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-800 p-8 sm:p-10 text-white shadow-xl border border-blue-500/20">
        <div className="absolute top-0 right-0 h-full w-1/3 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-400/25 via-transparent to-transparent pointer-events-none" />
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-slate-900/10 dark:bg-white/10 px-3 py-1 text-xs font-semibold tracking-wider text-blue-100 uppercase border border-white/20">
            2026 Accelerated Education Desk
          </div>
          <h1 className="font-sans font-extrabold text-3xl sm:text-5xl tracking-tight text-white leading-tight">
            Software Testing Mastery
          </h1>
          <p className="text-blue-100/90 text-sm sm:text-base leading-relaxed max-w-2xl font-sans">
            Your high-octane engineering sandbox, micro-interactive classrooms, and technical repository. Master static requirement audits, custom script test automation, and land senior QA positions.
          </p>
          <div className="flex flex-wrap gap-3 pt-4">
            <button
              id="dashboard-start-learning-btn"
              onClick={() => onNavigate("learning", 1)}
              className="rounded-xl bg-white hover:bg-slate-50 text-blue-700 px-6 py-3 text-xs font-bold transition-all hover:scale-[1.02] shadow-lg cursor-pointer flex items-center gap-1.5"
            >
              <GraduationCap className="w-4 h-4" />
              <span>Start Learning Syllabus</span>
            </button>
            <button
              id="dashboard-try-mock-btn"
              onClick={() => {
                // Navigate to career and ensure mock simulation subtab opens
                onNavigate("career");
              }}
              className="rounded-xl bg-blue-550 hover:bg-blue-500 bg-blue-650 text-white px-6 py-3 text-xs font-bold border border-blue-400/40 transition-all hover:scale-[1.02] cursor-pointer flex items-center gap-1.5"
            >
              <Bot className="w-4 h-4 text-amber-300" />
              <span>Try a Mock Interview</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid of Standard KPI Progress Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="dashboard-kpis">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xs flex items-center gap-4 transition-all hover:shadow-md">
          <div className="rounded-xl bg-blue-50 dark:bg-blue-950/50 p-3 text-blue-600 dark:text-blue-400 shrink-0">
            <Star className="h-6 w-6" />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-900 dark:text-slate-105 font-mono">{progress.xp}</div>
            <div className="text-xs text-slate-550 dark:text-slate-400 font-medium">Earned Experience Points</div>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xs flex items-center gap-4 transition-all hover:shadow-md">
          <div className="rounded-xl bg-emerald-50 dark:bg-emerald-950/50 p-3 text-emerald-600 dark:text-emerald-400 shrink-0">
            <CheckCircle2 className="h-6 w-6" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-bold text-slate-900 dark:text-slate-105 font-mono">{progressPercent}%</span>
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold shrink-0">{completedCount} / {totalSections}</span>
            </div>
            <div className="text-xs text-slate-550 dark:text-slate-400 font-medium mb-1%">Completed Chapters</div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 mt-1">
              <div 
                className="bg-emerald-500 h-1.5 rounded-full transition-all duration-500" 
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xs flex items-center gap-4 transition-all hover:shadow-md">
          <div className="rounded-xl bg-amber-50 dark:bg-amber-950/50 p-3 text-amber-500 shrink-0">
            <Award className="h-6 w-6" />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-900 dark:text-slate-105 font-mono">
              {progress.unlockedBadges.length} / {badges.length}
            </div>
            <div className="text-xs text-slate-550 dark:text-slate-400 font-medium font-sans">Unlocked Credentials</div>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xs flex items-center gap-4 transition-all hover:shadow-md">
          <div className="rounded-xl bg-indigo-50 dark:bg-indigo-950/40 p-3 text-indigo-600 dark:text-indigo-400 shrink-0">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-900 dark:text-slate-105 font-mono">
              {progress.labsCompleted.length} / 6
            </div>
            <div className="text-xs text-slate-550 dark:text-slate-400 font-medium">Completed Lab Sandboxes</div>
          </div>
        </div>
      </div>

      {/* Featured Modules Showcase Segment */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-blue-550 text-blue-600" />
              <span>Continue Core Syllabus Track</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-405">Bite-sized microlectures paired with category-matching engines and code verification checks.</p>
          </div>
          <button 
            onClick={() => onNavigate("learning", 1)}
            className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
          >
            See All Modules →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredModules.map((mod) => {
            const completedCountInMod = mod.sections.filter(s => progress.completedSections.includes(s.id)).length;
            const pct = Math.round((completedCountInMod / mod.sections.length) * 100);
            
            return (
              <div 
                key={mod.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-3xs hover:shadow-sm hover:border-blue-200 dark:hover:border-blue-900/60 transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      Module {mod.id}
                    </span>
                    <span className="text-[10px] font-mono font-bold text-blue-600 dark:text-blue-400">
                      {completedCountInMod}/{mod.sections.length} Lectures
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-850 dark:text-slate-150 leading-tight">
                    {mod.title}
                  </h3>
                  <p className="text-slate-500 dark:text-slate-400 text-xs line-clamp-2 leading-relaxed">
                    {mod.description}
                  </p>
                </div>

                <div className="space-y-3 pt-2">
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold">
                      <span>Module Track</span>
                      <span>{pct}% Completed</span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1 overflow-hidden">
                      <div 
                        className="bg-blue-600 h-1 rounded-full transition-all duration-300" 
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>

                  <button
                    onClick={() => onNavigate("learning", mod.id)}
                    className="w-full py-2 px-3 rounded-xl bg-slate-100 dark:bg-slate-850 hover:bg-blue-600 dark:hover:bg-blue-600 text-slate-700 dark:text-slate-300 hover:text-white dark:hover:text-white text-xs font-bold transition-all cursor-pointer text-center"
                    id={`feature-mod-btn-${mod.id}`}
                  >
                    {pct === 100 ? "Review Lectures Check" : "Continue Lecture Study"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Analysis Display: QA Metrics & Badge shelf */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Interactive Metrics Visualizer */}
        <div className="lg:col-span-2 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-900/95 p-6 text-slate-105 shadow-md flex flex-col justify-between">
          <div className="space-y-1.5 mb-6">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-indigo-400" />
              <h2 className="font-sans font-bold text-lg text-white">QA Metrics & Defect Intelligence</h2>
            </div>
            <p className="text-xs text-slate-400">
              Interactive analytic indicators mapping release readiness models and software failure thresholds. Hover over individual metrics to details.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            {/* SVG Visual Graphic */}
            <div className="md:col-span-6 flex flex-col items-center justify-center relative">
              <svg width="220" height="220" viewBox="0 0 200 200" className="mx-auto select-none">
                {/* SVG Radial Gauge for total coverage */}
                <circle cx="100" cy="100" r="80" fill="none" stroke="#1e293b" strokeWidth="12" />
                <circle 
                  cx="100" 
                  cy="100" 
                  r="80" 
                  fill="none" 
                  stroke="url(#blueGrad)" 
                  strokeWidth="12" 
                  strokeDasharray={`${2 * Math.PI * 80}`}
                  strokeDashoffset={`${2 * Math.PI * 80 * (1 - (0.65 + (progressPercent * 0.0035)))}`}
                  strokeLinecap="round"
                  transform="rotate(-90 100 100)"
                  className="transition-all duration-1000"
                />
                <defs>
                  <linearGradient id="blueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#3b82f6" />
                    <stop offset="100%" stopColor="#2563eb" />
                  </linearGradient>
                </defs>
                <text x="100" y="93" textAnchor="middle" fill="#94a3b8" fontSize="11" fontWeight="500">SYSTEM TESTING</text>
                <text x="100" y="118" textAnchor="middle" fill="#ffffff" fontSize="26" fontWeight="bold">
                  {Math.round(65 + (progressPercent * 0.35))}%
                </text>
                <text x="100" y="136" textAnchor="middle" fill="#3b82f6" fontSize="10" fontWeight="bold">SLA COVERAGE</text>
              </svg>
              <div className="text-center mt-2">
                <span className="inline-flex items-center gap-1.5 rounded-md bg-indigo-950 px-2.5 py-1 text-[10px] font-bold text-blue-300 border border-blue-900">
                  Exit Gate Target: 90% Code Coverage
                </span>
              </div>
            </div>

            {/* Severity KPI Bars list */}
            <div className="md:col-span-6 space-y-4">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Current Bug Inventory Severity ({totalBugsRecorded} Active Reports)
              </h3>
              <div className="space-y-3">
                {severityData.map((item) => (
                  <div 
                    key={item.name}
                    className="space-y-1 cursor-help group transition-all duration-200 p-2 rounded-lg hover:bg-slate-800"
                    onMouseEnter={() => setHoveredMetric(item.name)}
                    onMouseLeave={() => setHoveredMetric(null)}
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="flex items-center gap-2 text-slate-300 font-medium">
                        <span className="h-2 w-2 rounded-full animate-pulse-slow" style={{ backgroundColor: item.color }} />
                        {item.name}
                      </span>
                      <span className="font-mono text-white font-semibold">
                        {item.value} <span className="text-slate-500 font-normal">({Math.round((item.value / totalBugsRecorded) * 100)}%)</span>
                      </span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                      <div 
                        className="h-1.5 rounded-full transition-all duration-500"
                        style={{ 
                          backgroundColor: item.color, 
                          width: `${(item.value / 30) * 100}%` 
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Hover Metric Detail Drawer Panel */}
          <div className="mt-6 p-3 rounded-lg bg-slate-850/60 border border-slate-800 transition-all text-xs flex gap-2 items-center min-h-[48px]">
            {hoveredMetric ? (
              <>
                <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0 animate-bounce" />
                <span className="text-slate-300">
                  <strong>{hoveredMetric}:</strong> {severityData.find(d => d.name === hoveredMetric)?.desc}
                </span>
              </>
            ) : (
              <>
                <BookOpen className="h-4 w-4 text-blue-400 shrink-0" />
                <span className="text-slate-400">
                  Hover or select individual severity bars above to detail QA priority metrics.
                </span>
              </>
            )}
          </div>
        </div>

        {/* Badges Shelf Layout */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xs flex flex-col justify-between">
          <div className="space-y-1.5 mb-4">
            <h2 className="font-sans font-bold text-lg text-slate-900 dark:text-white flex items-center gap-2">
              <Award className="h-5 w-5 text-amber-500" />
              Progress Badges Shelf
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Complete course chapters, exercise sandboxes, and timed exams to claim core credentials.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-3" id="badges-grid">
            {badges.map((badge) => {
              const isUnlocked = progress.unlockedBadges.includes(badge.id);
              return (
                <div 
                  key={badge.id}
                  className={`group relative flex flex-col items-center p-2.5 rounded-xl border text-center transition-all ${
                    isUnlocked 
                      ? "bg-slate-50 dark:bg-slate-850 border-blue-200 dark:border-blue-900/50 shadow-xs" 
                      : "bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800/60 opacity-30 select-none grayscale"
                  }`}
                >
                  <div className={`rounded-xl p-2 mb-1.5 ${
                    isUnlocked ? "bg-amber-100 text-amber-600" : "bg-slate-105 text-slate-400"
                  }`}>
                    <Award className="h-4 w-4 sm:h-5 sm:w-5" />
                  </div>
                  <span className="text-[10px] font-bold text-slate-700 dark:text-slate-350 tracking-tight leading-tight line-clamp-1">
                    {badge.title}
                  </span>

                  {/* Tooltip hovering */}
                  <div className="pointer-events-none absolute bottom-full mb-2 left-1/2 -translate-x-1/2 w-48 bg-slate-950 text-white rounded-lg p-2.5 shadow-xl text-left scale-0 group-hover:scale-100 transition-all origin-bottom duration-150 z-25 text-[10px] space-y-1">
                    <div className="font-semibold text-amber-400">{badge.title}</div>
                    <div className="text-slate-300">{badge.description}</div>
                    <div className="text-[9px] font-bold mt-1 tracking-wider uppercase text-slate-500">
                      {isUnlocked ? "Status: Unlocked" : "Status: Locked"}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-6 pt-4 border-t border-slate-150 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-blue-600 dark:text-blue-400">
            <span>Unlocked Credentials:</span>
            <span>{progress.unlockedBadges.length} / {badges.length}</span>
          </div>
        </div>
      </div>

      {/* 2026 Tech Trends Insight Segment */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4">
        <h2 className="text-md font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-500 animate-pulse" />
          <span>Trending QA Architectures in 2026</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800/60 space-y-2">
            <h3 className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest flex items-center gap-1.5">
              <Bot className="w-4 h-4 text-blue-500" />
              AI Self-Healing Locators
            </h3>
            <p className="text-slate-600 dark:text-slate-401 text-xs leading-relaxed">
              Modern QA nodes use predictive models to dynamically adjust target element locators (CSS/XPath) whenever code releases adjust the button structures, decreasing test friction by 90%.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800/60 space-y-2">
            <h3 className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest flex items-center gap-1.5">
              <GitBranch className="w-4 h-4 text-emerald-500" />
              Shift-Left Requirement Audits
            </h3>
            <p className="text-slate-600 dark:text-slate-401 text-xs leading-relaxed">
              Catching defects during the initial product grooming phase saves up to 85% of release costs. Tester mindset shifting into documentation design guarantees flawless product scopes.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800/60 space-y-2">
            <h3 className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-indigo-500" />
              Shift-Right Chaos Observability
            </h3>
            <p className="text-slate-600 dark:text-slate-401 text-xs leading-relaxed">
              Injecting intentional runtime bugs, latency lags, and network exceptions directly inside active staging clusters to verify resilience metrics under heavy transaction spikes.
            </p>
          </div>
        </div>
      </div>

      {/* Real-World Corporate Alumnus Testimonies Carousel */}
      <div className="space-y-4">
        <h2 className="text-md font-bold text-slate-800 dark:text-white flex items-center gap-2">
          <Heart className="w-4.5 h-4.5 text-red-500" />
          <span>Success Stories from our Alumnus</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((test, index) => (
            <div 
              key={index}
              className="p-5 rounded-2xl border border-slate-150 dark:border-slate-800/80 bg-slate-100/50 dark:bg-slate-900/40 text-left space-y-3 relative flex flex-col justify-between"
            >
              <p className="text-xs text-slate-600 dark:text-slate-350 italic leading-relaxed">
                "{test.quote}"
              </p>
              <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800/60">
                <div>
                  <div className="text-xs font-bold text-slate-805 dark:text-slate-200">{test.author}</div>
                  <div className="text-[10px] text-slate-400 dark:text-slate-500">{test.role}</div>
                </div>
                <span className="text-[8px] uppercase tracking-wider font-extrabold bg-blue-50 dark:bg-blue-900/30 text-blue-650 dark:text-blue-405 border border-blue-100 dark:border-blue-900 px-2 py-0.5 rounded">
                  {test.badge}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Check, 
  X, 
  HelpCircle, 
  BookmarkCheck, 
  ArrowRight, 
  Lightbulb, 
  HeartHandshake, 
  ExternalLink,
  Shuffle,
  ShieldCheck,
  Award,
  Trophy,
  BookOpen,
  PlayCircle,
  Code2,
  ListRestart,
  GitPullRequest,
  CheckCircle,
  Sparkles,
  Info
} from "lucide-react";
import { Module, Section, UserProgress, QuizQuestion, MatchOption, DragDropOption } from "../types";
import QuizModal from "./QuizModal";

interface ModuleViewerProps {
  module: Module;
  progress: UserProgress;
  onUpdateProgress: (progress: UserProgress) => void;
  initialSectionId?: string;
}

export default function ModuleViewer({ module, progress, onUpdateProgress, initialSectionId }: ModuleViewerProps) {
  // Store selected sub-section index inside the module
  const [activeTab, setActiveTab] = useState<string>("");

  // Content Navigation subtabs inside active lecture: "theory" | "examples" | "practice" | "quiz"
  const [activeContentTab, setActiveContentTab] = useState<"theory" | "examples" | "practice" | "quiz">("theory");

  // Quiz Modal visibility state
  const [isQuizOpen, setIsQuizOpen] = useState<boolean>(false);

  // Quiz active choice tracking state
  const [quizAnswers, setQuizAnswers] = useState<{ [questionId: string]: number }>({});
  const [quizSubmitted, setQuizSubmitted] = useState<{ [questionId: string]: boolean }>({});

  // Matching pair activity tracking states
  const [selectedConcept, setSelectedConcept] = useState<string | null>(null);
  const [selectedDescription, setSelectedDescription] = useState<string | null>(null);
  const [matchedPairs, setMatchedPairs] = useState<string[]>([]);
  const [matchStatusMsg, setMatchStatusMsg] = useState<string>("");

  // Category Sorting game states
  const [sortedItems, setSortedItems] = useState<{ [itemId: string]: string }>({});
  const [sortSubmitted, setSortSubmitted] = useState<boolean>(false);
  const [sortMessage, setSortMessage] = useState<string>("");

  // Case Study QA scores tracking state
  const [caseAnswers, setCaseAnswers] = useState<{ [questionId: string]: number }>({});
  const [caseSubmitted, setCaseSubmitted] = useState<boolean>(false);

  // Synchronise sub-section tab from initialSectionId prop changes or selection swaps
  useEffect(() => {
    if (initialSectionId && module.sections.some(s => s.id === initialSectionId)) {
      setActiveTab(initialSectionId);
    } else if (module && module.sections.length > 0) {
      setActiveTab(module.sections[0].id);
    }
    // Set default content subtab to theory when changing section or module
    setActiveContentTab("theory");
    
    // Clean up interactive states
    setQuizAnswers({});
    setQuizSubmitted({});
    setSelectedConcept(null);
    setSelectedDescription(null);
    setMatchedPairs([]);
    setMatchStatusMsg("");
    setSortedItems({});
    setSortSubmitted(false);
    setSortMessage("");
    setCaseAnswers({});
    setCaseSubmitted(false);
  }, [module, initialSectionId]);

  const currentSection = module.sections.find((s) => s.id === activeTab);

  if (!currentSection) {
    return (
      <div className="p-8 text-center bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
        <p className="text-slate-500 text-sm">No section selected. Choose a module from the sidebar.</p>
      </div>
    );
  }

  // Handle section complete marking and award XP
  const handleMarkComplete = () => {
    if (!progress.completedSections.includes(currentSection.id)) {
      const updatedSects = [...progress.completedSections, currentSection.id];
      let newXp = progress.xp + 50; // award 50 XP for reading

      // Dynamic check for Module 1 completion badge
      const unlockedBadges = [...progress.unlockedBadges];
      if (module.id === 1 && !unlockedBadges.includes("intro")) {
        unlockedBadges.push("intro");
        newXp += 100; // bonus badge point
      }

      // Check for basics of testing fundamentals completed badge (Module 2)
      if (module.id === 2 && !unlockedBadges.includes("fundamentals")) {
        const mod2Sects = ["2.1", "2.2", "2.3", "2.4", "2.5", "2.6", "2.7", "2.8"];
        const hasCompletedAllMod2 = mod2Sects.every((id) => updatedSects.includes(id));
        if (hasCompletedAllMod2) {
          unlockedBadges.push("fundamentals");
          newXp += 150;
        }
      }

      // Check for methodology module badge (Module 5)
      if (module.id === 5 && !unlockedBadges.includes("design") && updatedSects.includes("5.1")) {
        unlockedBadges.push("design");
        newXp += 100;
      }

      onUpdateProgress({
        ...progress,
        completedSections: updatedSects,
        xp: newXp,
        unlockedBadges
      });
    }
  };

  const isSectionComplete = progress.completedSections.includes(currentSection.id);

  // Compile all quiz questions defined across the active module's sections
  const moduleQuestions: QuizQuestion[] = module.sections.reduce((acc, s) => {
    if (s.quiz && s.quiz.length > 0) {
      acc.push(...s.quiz);
    }
    return acc;
  }, [] as QuizQuestion[]);

  // Modules metadata tracking for quiz completion
  const completedSectionsInModule = module.sections.filter((s) => progress.completedSections.includes(s.id));
  const isModuleFullyCompleted = completedSectionsInModule.length === module.sections.length;
  const hasTakenQuiz = progress.completedModuleQuizzes?.includes(module.id);
  const bestQuizScore = progress.quizScores?.[module.id] || 0;

  // Submit quiz answer logic
  const handleSelectQuizOption = (qId: string, optIndex: number) => {
    if (quizSubmitted[qId]) return;
    setQuizAnswers({ ...quizAnswers, [qId]: optIndex });
  };

  const handleSubmitQuizQuestion = (q: QuizQuestion) => {
    if (quizAnswers[q.id] === undefined) return;
    setQuizSubmitted({ ...quizSubmitted, [q.id]: true });

    // Answer evaluation and XP awards
    const isCorrect = quizAnswers[q.id] === q.correctAnswer;
    if (isCorrect) {
      onUpdateProgress({
        ...progress,
        xp: progress.xp + 25
      });
    }
  };

  // Interactive Match-pairs logic
  const handleMatchClick = (type: "concept" | "description", id: string) => {
    if (type === "concept") {
      setSelectedConcept(id);
      if (selectedDescription) {
        checkPairMatch(id, selectedDescription);
      }
    } else {
      setSelectedDescription(id);
      if (selectedConcept) {
        checkPairMatch(selectedConcept, id);
      }
    }
  };

  const checkPairMatch = (conceptId: string, descId: string) => {
    if (conceptId === descId) {
      const newMatched = [...matchedPairs, conceptId];
      setMatchedPairs(newMatched);
      setMatchStatusMsg("Excellent Match Found! +15 XP");
      setSelectedConcept(null);
      setSelectedDescription(null);

      // Award XP
      let plusXp = 15;
      if (currentSection.matchPairs && newMatched.length === currentSection.matchPairs.length) {
        setMatchStatusMsg("Awesome! All Pairs Completed Successfully! +50 XP Bonus");
        plusXp += 50;
      }
      onUpdateProgress({
        ...progress,
        xp: progress.xp + plusXp
      });
    } else {
      setMatchStatusMsg("Mismatch, please review the definition card again.");
      setTimeout(() => {
        setSelectedConcept(null);
        setSelectedDescription(null);
      }, 800);
    }
  };

  // Sorting Categorization game logic
  const handleSortItemClick = (itemId: string, category: string) => {
    if (sortSubmitted) return;
    setSortedItems({ ...sortedItems, [itemId]: category });
  };

  const handleSubmitSortingGame = () => {
    if (!currentSection.sortOptions) return;
    
    const allRight = currentSection.sortOptions.every(
      (opt) => sortedItems[opt.id] === opt.category
    );

    setSortSubmitted(true);
    if (allRight) {
      setSortMessage("Absolutely Spot-on! You categorized all elements 100% correctly! +75 XP");
      onUpdateProgress({
        ...progress,
        xp: progress.xp + 75
      });
    } else {
      setSortMessage("Not quite perfect. Review structural paths vs performance parameters and retry!");
    }
  };

  const handleResetSortingGame = () => {
    setSortedItems({});
    setSortSubmitted(false);
    setSortMessage("");
  };

  // Case Study questions validation logic
  const handleCaseSelect = (qId: string, index: number) => {
    if (caseSubmitted) return;
    setCaseAnswers({ ...caseAnswers, [qId]: index });
  };

  const handleSubmitCaseStudy = () => {
    if (!currentSection.caseStudy) return;

    const allCorrect = currentSection.caseStudy.questions.every(
      (q) => caseAnswers[q.id] === q.correct
    );

    setCaseSubmitted(true);
    if (allCorrect) {
      onUpdateProgress({
        ...progress,
        xp: progress.xp + 80
      });
    }
  };

  return (
    <div className="space-y-8 animate-fade-in" id="module-viewer-arena">
      
      {/* Module Title Banner Panel */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-xs relative">
        <div className="absolute top-4 right-6 flex items-center gap-1.5 text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">
          <BookOpen className="w-3.5 h-3.5 text-blue-500" />
          <span>Lecture Portal</span>
        </div>
        <p className="text-[10px] uppercase font-bold text-blue-600 dark:text-blue-400 tracking-wider">Module {module.id}</p>
        <h1 className="font-sans font-extrabold text-2xl text-slate-900 dark:text-white mt-1 leading-tight">{module.title}</h1>
        <p className="text-slate-500 dark:text-slate-400 text-sm mt-1.5">{module.description}</p>

        {/* Lessons checklist rail - STICKY layout on desktop */}
        <div 
          className="flex flex-wrap gap-2 mt-5 border-t border-slate-100 dark:border-slate-800 pt-5 overflow-x-auto scrollbar-none" 
          id="subsection-tabs-rail"
        >
          {module.sections.map((sect) => {
            const isCompletedSect = progress.completedSections.includes(sect.id);
            const isCurrent = activeTab === sect.id;
            return (
              <button
                key={sect.id}
                onClick={() => {
                  setActiveTab(sect.id);
                  setActiveContentTab("theory"); // Reset subtab to theory on click
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
                  isCurrent 
                    ? "bg-blue-600 text-white shadow-sm" 
                    : "bg-slate-100 dark:bg-slate-800 text-slate-650 dark:text-slate-300 hover:bg-slate-200"
                }`}
              >
                {isCompletedSect && <BookmarkCheck className="h-3.5 w-3.5 text-emerald-500 shrink-0" />}
                <span>{sect.id}: {sect.title}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Modern Horizontal Navigation Tabs: Theory, Examples, Practice, Quiz */}
      <div className="border-b border-slate-200 dark:border-slate-800 flex gap-1 sm:gap-2">
        {[
          { id: "theory", label: "Theory & Guidelines", icon: BookOpen },
          { id: "examples", label: "Real Examples & Visuals", icon: Code2 },
          { id: "practice", label: "Active Sandbox Practice", icon: PlayCircle },
          { id: "quiz", label: "Evaluation Quiz", icon: Award }
        ].map((sub) => {
          const IconComponent = sub.icon;
          const isSelected = activeContentTab === sub.id;
          return (
            <button
              key={sub.id}
              onClick={() => setActiveContentTab(sub.id as any)}
              className={`flex items-center gap-1.5 px-3 sm:px-5 py-3 text-xs sm:text-sm font-bold transition-all border-b-2 cursor-pointer ${
                isSelected 
                  ? "border-blue-600 dark:border-blue-500 text-blue-600 dark:text-blue-505" 
                  : "border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 hover:border-slate-200"
              }`}
            >
              <IconComponent className="h-4 w-4 shrink-0" />
              <span>{sub.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Area: Render Active Content Tab */}
      <div id="active-classroom-viewport" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left column Content blocks */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* 1. Theory Tab Workspace */}
          {activeContentTab === "theory" && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-3xs space-y-6 animate-fade-in">
              <div className="flex items-center justify-between pb-4 border-b border-slate-150 dark:border-slate-800/80">
                <span className="text-[10px] font-bold text-slate-400 dark:text-slate-505 uppercase tracking-wider">TEACHER'S LECTURE MANUAL</span>
                <button
                  id="mark-complete-btn"
                  onClick={handleMarkComplete}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer border transition-all ${
                    isSectionComplete 
                      ? "bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400" 
                      : "bg-blue-600 border-blue-600 hover:bg-blue-500 text-white shadow-sm"
                  }`}
                >
                  <Check className="h-4 w-4" />
                  <span>{isSectionComplete ? "Completed ✓ (+50 XP Claimed)" : "Mark Lecture Completed (+50 XP)"}</span>
                </button>
              </div>

              {/* What is inside */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="p-1 rounded bg-blue-50 dark:bg-blue-950/40 text-blue-650 dark:text-blue-400">
                    <Lightbulb className="h-4.5 w-4.5" />
                  </div>
                  <h3 className="font-sans font-bold text-slate-900 dark:text-slate-105 text-sm uppercase tracking-wide">Definition & General Aspect</h3>
                </div>
                <p className="text-slate-650 dark:text-slate-350 text-sm leading-relaxed font-sans">{currentSection.content.what}</p>
              </div>

              {/* When & Why matrices */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-150 dark:border-slate-800 space-y-1.5">
                  <h4 className="font-bold text-slate-800 dark:text-slate-200 text-xs uppercase tracking-wide flex items-center gap-1.5">
                    <CheckCircle className="h-4 w-4 text-emerald-650 dark:text-emerald-400" />
                    When to use?
                  </h4>
                  <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">{currentSection.content.whenToUse}</p>
                </div>

                <div className="p-4 rounded-xl bg-blue-50/40 dark:bg-blue-950/20 border border-blue-100/40 dark:border-blue-900/30 space-y-1.5">
                  <h4 className="font-bold text-blue-900 dark:text-blue-200 text-xs uppercase tracking-wide flex items-center gap-1.5">
                    <ShieldCheck className="h-4 w-4 text-blue-600" />
                    Why critical?
                  </h4>
                  <p className="text-slate-650 dark:text-slate-350 text-xs leading-relaxed">{currentSection.content.whyToUse}</p>
                </div>
              </div>

              {/* Practical Steps */}
              <div className="space-y-3">
                <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
                  <Code2 className="w-4 h-4 text-blue-600" />
                  <span>How to Apply (Practical Guidelines)</span>
                </h3>
                <div className="bg-slate-50 dark:bg-slate-850/40 border border-slate-150 dark:border-slate-800 rounded-xl p-5">
                  <ul className="space-y-4">
                    {currentSection.content.howToUse.split("\n").map((step, idx) => (
                      <li key={idx} className="flex gap-3 text-xs text-slate-600 dark:text-slate-350 leading-relaxed font-sans">
                        <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-400 font-bold text-[10px]">
                          {idx + 1}
                        </span>
                        <span>{step.replace(/^\d+[\.\-\s]*/, '')}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* 2. Examples & Visual Diagrams Tab */}
          {activeContentTab === "examples" && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-3xs space-y-8 animate-fade-in">
              
              <div className="space-y-1 border-b border-slate-100 dark:border-slate-800 pb-4">
                <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest">Visual Syllabus Charts</span>
                <h3 className="font-bold text-slate-900 dark:text-white text-md">Architectural Concept Visualisations</h3>
                <p className="text-slate-505 dark:text-slate-400 text-xs">Analyze the production-grade topological layouts of software validation and diagnostic loops.</p>
              </div>

              {/* DYNAMIC DIAGRAM COMPONENT */}
              {module.id === 1 && (
                <div className="space-y-4" id="sdlc-module-diagram">
                  <div className="text-xs font-bold text-slate-500 uppercase tracking-wide">Process Loop A: Shift-Left Testing Pipeline</div>
                  <div className="p-5 rounded-2xl bg-slate-950 text-white border border-slate-800 space-y-6">
                    <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 text-center text-[10px] font-mono select-none">
                      
                      <div className="p-2.5 rounded bg-blue-900/40 border border-blue-500 shadow-inner flex flex-col justify-between h-24">
                        <span className="text-blue-300 font-extrabold">STEP 1</span>
                        <span className="font-sans font-bold leading-tight">Requirement Audit 🔥</span>
                        <span className="text-[8px] text-emerald-400 bg-emerald-950 px-1 py-0.5 rounded font-sans">QA Active</span>
                      </div>

                      <div className="p-2.5 rounded bg-slate-900 border border-slate-800/80 flex flex-col justify-between h-24">
                        <span className="text-slate-500">STEP 2</span>
                        <span className="font-sans leading-tight">Design & Wireframe</span>
                        <span className="text-[8px] text-slate-550 leading-none">Draft Specs</span>
                      </div>

                      <div className="p-2.5 rounded bg-slate-900 border border-slate-800/85 flex flex-col justify-between h-24">
                        <span className="text-slate-500">STEP 3</span>
                        <span className="font-sans leading-tight">Code Authoring</span>
                        <span className="text-[8px] text-slate-550 leading-none">Dev branch</span>
                      </div>

                      <div className="p-2.5 rounded bg-slate-900 border border-slate-800/85 flex flex-col justify-between h-24">
                        <span className="text-slate-500">STEP 4</span>
                        <span className="font-sans leading-tight">Integration Tests</span>
                        <span className="text-[8px] text-slate-550 leading-none">Jenkins Build</span>
                      </div>

                      <div className="p-2.5 rounded bg-slate-900 border border-slate-800/85 flex flex-col justify-between h-24">
                        <span className="text-slate-500">STEP 5</span>
                        <span className="font-sans leading-tight">Sandbox Demo labs</span>
                        <span className="text-[8px] text-slate-550 leading-none">Bug Hunt</span>
                      </div>

                      <div className="p-2.5 bg-indigo-950 border border-indigo-500 shadow-lg rounded flex flex-col justify-between h-24">
                        <span className="text-indigo-400 font-extrabold font-mono">RELEASE</span>
                        <span className="font-sans font-bold leading-tight">Deploy Production</span>
                        <span className="text-[8px] text-slate-350 leading-none font-sans">SLA: 100% Ok</span>
                      </div>

                    </div>
                    <div className="rounded-xl bg-slate-900 p-3.5 border border-slate-850 text-left text-xs text-slate-350 leading-relaxed font-sans">
                      <strong className="text-indigo-400 flex items-center gap-1">
                        <Info className="w-3.5 h-3.5 shrink-0" />
                        <span>Shift-Left Concept Explanation:</span>
                      </strong>
                      <p className="mt-1">
                        By deploying QA testers right inside **Step 1: Requirement Audit**, the engineering desk resolves 85% of structural conflicts (ambiguities or logically impossible features) before a developer even edits a single line of typescript code. This saves massive product budget!
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {module.id === 2 && (
                <div className="space-y-4" id="testing-levels-diagram">
                  <div className="text-xs font-bold text-slate-500 uppercase tracking-wide">Process Loop B: Testing Levels Chain</div>
                  <div className="p-5 rounded-2xl bg-slate-950 text-white border border-slate-800 space-y-4">
                    <div className="flex flex-col gap-2 max-w-lg mx-auto select-none font-mono text-[11px]">
                      
                      <div className="p-3 bg-red-950/20 border border-red-900 text-red-100 rounded-lg flex items-center justify-between shadow-xs">
                        <span>4. User Acceptance Testing (UAT)</span>
                        <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-red-900/40 text-red-200 border border-red-800 font-sans">End Customers</span>
                      </div>

                      <div className="flex justify-center text-slate-600">▲</div>

                      <div className="p-3 bg-amber-950/20 border border-amber-900 text-amber-100 rounded-lg flex items-center justify-between shadow-xs">
                        <span>3. System-Wide Integration Verification </span>
                        <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-amber-900/40 text-amber-250 border border-amber-800 font-sans">Testing Team</span>
                      </div>

                      <div className="flex justify-center text-slate-600">▲</div>

                      <div className="p-3 bg-blue-950/20 border border-blue-900 text-blue-100 rounded-lg flex items-center justify-between shadow-xs">
                        <span>2. API & Component Integration Verification</span>
                        <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-blue-900/40 text-blue-200 border border-blue-800 font-sans">QA + Devs</span>
                      </div>

                      <div className="flex justify-center text-slate-600">▼</div>

                      <div className="p-3 bg-slate-900 border border-slate-800 text-slate-300 rounded-lg flex items-center justify-between shadow-xs">
                        <span>1. Unit Code Assertions</span>
                        <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 font-sans">Developer Node</span>
                      </div>

                    </div>
                    <p className="text-[11px] text-slate-400 font-sans leading-relaxed text-center italic mt-2">
                       Verification flows upwards from individual code lines (Units) to composite connections, systems, and client acceptance.
                    </p>
                  </div>
                </div>
              )}

              {module.id === 5 && (
                <div className="space-y-4" id="bva-matrix-diagram">
                  <div className="text-xs font-bold text-slate-500 uppercase tracking-wide">Process Loop C: 2026 Black-Box Input Separation Matrix</div>
                  <div className="p-5 rounded-2xl bg-slate-950 text-white border border-slate-800 space-y-4">
                    <div className="text-center font-mono text-xs select-none">
                      <div className="text-blue-400 font-bold uppercase text-[10px] mb-2 tracking-wider">Example: Age input validation (Minimum age requirement: 18)</div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                        
                        <div className="p-3 rounded-lg border border-red-900 bg-red-950/30 text-red-200">
                          <div className="text-[9px] font-bold text-red-500 select-all tracking-widest">INVALID PARTITION</div>
                          <div className="text-sm font-bold mt-1">Age &lt; 18</div>
                          <p className="text-[10px] mt-1 text-slate-400 leading-snug">Boundary value: 17<br />Assert Outcome: Exception Rejected</p>
                        </div>

                        <div className="p-3 rounded-lg border border-emerald-900 bg-emerald-950/30 text-emerald-200 shadow-inner">
                          <div className="text-[9px] font-bold text-emerald-500 select-all tracking-widest">VALID PARTITION</div>
                          <div className="text-sm font-bold mt-1">18 &le; Age &le; 100</div>
                          <p className="text-[10px] mt-1 text-slate-405 leading-snug">Boundary values: 18, 19, 100<br />Assert Outcome: Active Approved</p>
                        </div>

                        <div className="p-3 rounded-lg border border-red-900 bg-red-950/30 text-red-200">
                          <div className="text-[9px] font-bold text-red-500 select-all tracking-widest">INVALID PARTITION</div>
                          <div className="text-sm font-bold mt-1">Age &gt; 100</div>
                          <p className="text-[10px] mt-1 text-slate-400 leading-snug">Boundary value: 101<br />Assert Outcome: Exception Rejected</p>
                        </div>

                      </div>

                    </div>
                  </div>
                </div>
              )}

              {/* General module support loop visual if none of above */}
              {module.id !== 1 && module.id !== 2 && module.id !== 5 && (
                <div className="space-y-4" id="general-verify-diagram">
                  <div className="text-xs font-bold text-slate-500 uppercase tracking-wide">Verification Loop: Tester Feedback Pipeline</div>
                  <div className="p-5 rounded-2xl bg-slate-950 text-white border border-slate-800 flex flex-col md:flex-row items-center justify-around gap-4 font-mono text-[10px] select-none text-center">
                    <div className="p-3 bg-indigo-950 rounded-lg border border-indigo-500">
                      <strong>Code Commit Run</strong>
                      <p className="text-slate-400 mt-1">Webhook triggers</p>
                    </div>
                    <div className="text-indigo-400">➜</div>
                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                      <strong>Automated Suite Runs</strong>
                      <p className="text-slate-400 mt-1">Verifies BVA gates</p>
                    </div>
                    <div className="text-indigo-400">➜</div>
                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                      <strong>Self-Healing Selectors</strong>
                      <p className="text-slate-400 mt-1">Remediates layout change</p>
                    </div>
                    <div className="text-indigo-400">➜</div>
                    <div className="p-3 bg-emerald-950 rounded-lg border border-emerald-505">
                      <strong>Exit Gate Sign Off</strong>
                      <p className="text-slate-400 mt-1">Bonus XP Claimed</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Dynamic examples list details */}
              <div className="space-y-4 pt-2">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">Real-World Analogies & Failure Cases</h4>
                <div className="grid grid-cols-1 gap-4">
                  {currentSection.content.examples.map((ex, idx) => (
                    <div key={idx} className="p-4 rounded-2xl border border-blue-100 dark:border-blue-900/40 bg-blue-50/10 dark:bg-blue-950/20 flex gap-3 text-left">
                      <div className="text-blue-600 dark:text-blue-400 shrink-0 mt-0.5 animate-pulse">
                        <HelpCircle className="h-5 w-5" />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs font-extrabold text-blue-900 dark:text-blue-300">
                          {ex.startsWith("Analogy:") ? "Historical Analogy Matrix" : ex.startsWith("Historical") ? "Historical Failure Incident Case Study" : "Corporate Production Scenario"}
                        </div>
                        <p className="text-xs text-slate-655 dark:text-slate-350 leading-relaxed font-sans mt-1">
                          {ex.substring(ex.indexOf(":") === -1 ? 0 : ex.indexOf(":") + 2)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* 3. Sandbox Interactive Practice Tab */}
          {activeContentTab === "practice" && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-850 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-3xs space-y-6 flex flex-col justify-between animate-fade-in animate-pulse-slow">
              
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold text-blue-600 dark:text-blue-400 tracking-wider">SKILLS VERIFICATION ARENA</span>
                <h2 className="font-sans font-bold text-lg text-slate-900 dark:text-white">Interactive Sandbox Exercise</h2>
                <p className="text-slate-500 dark:text-slate-400 text-xs">Analyze the concept parameters below, pass the testing criteria, and claim your experience points.</p>
              </div>

              {/* Render dynamic sub-games in section */}
              
              {/* Game type 1: Case Study */}
              {currentSection.caseStudy && (
                <div className="space-y-6 pt-4" id="case-study-activity">
                  <div className="p-5 rounded-2xl bg-slate-950 text-slate-100 border border-slate-800 space-y-3 shadow-inner">
                    <h3 className="font-sans font-bold text-amber-400 text-xs flex items-center gap-1.5 uppercase tracking-wider">
                      <Award className="h-4.5 w-4.5 text-amber-505 shrink-0" />
                      System Diagnostic: {currentSection.caseStudy.title}
                    </h3>
                    <p className="text-slate-300 text-xs leading-relaxed font-mono">
                      {currentSection.caseStudy.scenario}
                    </p>
                  </div>

                  <div className="space-y-5">
                    {currentSection.caseStudy.questions.map((q) => {
                      const isCorrect = caseAnswers[q.id] === q.correct;
                      const hasSelected = caseAnswers[q.id] !== undefined;
                      return (
                        <div key={q.id} className="space-y-2.5 p-4 rounded-xl border border-slate-150 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-left">
                          <div className="text-xs font-bold text-slate-850 dark:text-slate-200">{q.question}</div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                            {q.choices.map((choice, cidx) => {
                              const isSelected = caseAnswers[q.id] === cidx;
                              return (
                                <button
                                  key={cidx}
                                  disabled={caseSubmitted}
                                  onClick={() => handleCaseSelect(q.id, cidx)}
                                  className={`text-left p-3 rounded-xl text-xs leading-normal transition-all font-bold cursor-pointer border ${
                                    isSelected 
                                      ? "bg-blue-605 bg-blue-600 border-blue-600 text-white" 
                                      : "bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-800 text-slate-650 dark:text-slate-300 hover:bg-slate-50"
                                  }`}
                                >
                                  {choice}
                                </button>
                              );
                            })}
                          </div>
                          {caseSubmitted && (
                            <div className={`p-3.5 rounded-xl text-xs mt-2 font-sans ${
                              isCorrect ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-805 dark:text-emerald-400 border border-emerald-100" : "bg-red-50 dark:bg-red-950/20 text-red-800 dark:text-red-400 border border-red-100"
                            }`}>
                              <strong>{isCorrect ? "✓ Correct Identification!" : "✗ Defect Diagnosis Failed."}</strong> {q.explanation}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {!caseSubmitted ? (
                    <button
                      onClick={handleSubmitCaseStudy}
                      disabled={currentSection.caseStudy.questions.some(q => caseAnswers[q.id] === undefined)}
                      className="w-full rounded-xl bg-blue-600 text-white font-bold text-xs py-3 hover:bg-blue-505 hover:bg-blue-600 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      Submit Failure Assessment
                    </button>
                  ) : (
                    <button
                      onClick={() => { setCaseAnswers({}); setCaseSubmitted(false); }}
                      className="w-full rounded-xl bg-slate-100 dark:bg-slate-850 text-slate-700 dark:text-slate-300 font-bold text-xs py-3 hover:bg-slate-200 transition-all cursor-pointer"
                    >
                      Reset & Retake Sandbox Audit
                    </button>
                  )}
                </div>
              )}

              {/* Game type 2: Multi-choice Quiz */}
              {currentSection.quiz && currentSection.quiz.length > 0 && (
                <div className="space-y-6 pt-4" id="quiz-question-activity">
                  {currentSection.quiz.map((q) => {
                    const hasSubmitted = quizSubmitted[q.id];
                    const selectedIndex = quizAnswers[q.id];
                    const isCorrect = selectedIndex === q.correctAnswer;

                    return (
                      <div key={q.id} className="p-5 border border-slate-150 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-900/60 text-left space-y-4 shadow-3xs">
                        <div className="flex gap-2.5 items-start">
                          <span className="mt-0.5 rounded-full bg-blue-50 dark:bg-blue-950 p-1 text-blue-600">
                            <HelpCircle className="h-4.5 w-4.5" />
                          </span>
                          <div className="text-xs font-bold text-slate-900 dark:text-slate-105 leading-relaxed font-sans">{q.question}</div>
                        </div>

                        <div className="space-y-2 mt-3" id={`options-grid-${q.id}`}>
                          {q.options.map((opt, oIdx) => {
                            const isOptionSelected = selectedIndex === oIdx;
                            let btnStyle = "bg-white dark:bg-slate-850 border-slate-205 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-305";

                            if (hasSubmitted) {
                              if (oIdx === q.correctAnswer) {
                                btnStyle = "bg-emerald-50 dark:bg-emerald-955/20 border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-400 font-bold";
                              } else if (isOptionSelected) {
                                btnStyle = "bg-red-50 dark:bg-red-955/20 border-red-350 dark:border-red-800 text-red-800 dark:text-red-400";
                              } else {
                                btnStyle = "bg-white dark:bg-slate-850 border-slate-150 dark:border-slate-800 text-slate-400 dark:text-slate-550 opacity-50";
                              }
                            } else if (isOptionSelected) {
                              btnStyle = "bg-blue-50 dark:bg-blue-955/40 border-blue-400 text-blue-900 dark:text-blue-300 font-bold";
                            }

                            return (
                              <button
                                key={oIdx}
                                disabled={hasSubmitted}
                                onClick={() => handleSelectQuizOption(q.id, oIdx)}
                                className={`w-full text-left p-3.5 rounded-xl border text-xs leading-normal transition-all flex items-center justify-between cursor-pointer font-bold ${btnStyle}`}
                              >
                                <span>{opt}</span>
                                {hasSubmitted && oIdx === q.correctAnswer && <Check className="h-4 w-4 text-emerald-600 shrink-0" />}
                                {hasSubmitted && isOptionSelected && oIdx !== q.correctAnswer && <X className="h-4 w-4 text-red-650 shrink-0" />}
                              </button>
                            );
                          })}
                        </div>

                        {/* Quiz validation feedback */}
                        {hasSubmitted && (
                          <div className={`p-4 rounded-xl text-xs leading-relaxed border ${isCorrect ? "bg-emerald-50 dark:bg-emerald-955/20 text-emerald-800 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/40" : "bg-red-50 dark:bg-red-955/20 text-red-800 dark:text-red-400 border-red-105 dark:border-red-900/40"}`} id={`quiz-feedback-${q.id}`}>
                            <strong className="block font-bold mb-1">{isCorrect ? "✓ Correct Assertion! (+25 XP Claimed)" : "✗ Incorrect logic trace."}</strong>
                            <p className="font-sans font-normal leading-relaxed">{q.explanation}</p>
                          </div>
                        )}

                        {!hasSubmitted && (
                          <button
                            onClick={() => handleSubmitQuizQuestion(q)}
                            disabled={selectedIndex === undefined}
                            className="text-xs font-bold bg-slate-900 dark:bg-blue-600 hover:bg-slate-800 dark:hover:bg-blue-500 text-white rounded-xl px-4 py-2 hover:bg-slate-800 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                          >
                            Lock Answer & Validate
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Game type 3: Matching definitions */}
              {currentSection.matchPairs && currentSection.matchPairs.length > 0 && (
                <div className="space-y-4 pt-4" id="match-pairs-activity">
                  <div className="text-xs text-slate-500 bg-slate-50 dark:bg-slate-850 p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 font-sans leading-relaxed">
                    <strong>Direct Connection Sandbox:</strong> Select a concept from the left panel, and then select its corresponding explanation block in the right panel to secure code points.
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Left Concept panel */}
                    <div className="space-y-2 text-left">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">Testing Concepts</div>
                      {currentSection.matchPairs.map((pair) => {
                        const isMatched = matchedPairs.includes(pair.id);
                        const isSelected = selectedConcept === pair.id;
                        
                        return (
                          <button
                            key={pair.id}
                            disabled={isMatched}
                            onClick={() => handleMatchClick("concept", pair.id)}
                            className={`w-full text-left p-3.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                              isMatched 
                                ? "bg-slate-50 dark:bg-slate-850 border-emerald-250 dark:border-emerald-900/40 text-slate-400 dark:text-slate-550 line-through" 
                                : isSelected 
                                  ? "bg-blue-600 border-blue-600 text-white scale-[1.01]" 
                                  : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-800 text-slate-650 dark:text-slate-300 hover:bg-slate-50"
                            }`}
                          >
                            {pair.concept}
                          </button>
                        );
                      })}
                    </div>

                    {/* Right Description panel */}
                    <div className="space-y-2 text-left">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-505">Explanations</div>
                      {currentSection.matchPairs
                        .map((p) => p)
                        .sort((a, b) => a.id.localeCompare(b.id) * -1)
                        .map((pair) => {
                          const isMatched = matchedPairs.includes(pair.id);
                          const isSelected = selectedDescription === pair.id;

                          return (
                            <button
                              key={pair.id}
                              disabled={isMatched}
                              onClick={() => handleMatchClick("description", pair.id)}
                              className={`w-full text-left p-3.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                                isMatched 
                                  ? "bg-slate-50 dark:bg-slate-850 border-emerald-250 dark:border-emerald-900/40 text-slate-400 dark:text-slate-550 line-through" 
                                  : isSelected 
                                    ? "bg-blue-600 border-blue-600 text-white scale-[1.01]" 
                                    : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-800 text-slate-650 dark:text-slate-300 hover:bg-slate-50"
                              }`}
                            >
                              {pair.description}
                            </button>
                          );
                        })}
                    </div>
                  </div>

                  {matchStatusMsg && (
                    <div className="p-3 bg-blue-50 dark:bg-blue-950 border border-blue-150 rounded-xl text-center font-bold text-xs text-blue-800 dark:text-blue-300 animate-pulse">
                      {matchStatusMsg}
                    </div>
                  )}

                  {matchedPairs.length === currentSection.matchPairs.length && (
                    <button
                      onClick={() => setMatchedPairs([])}
                      className="mt-2 w-full rounded-xl bg-slate-100 dark:bg-slate-855 border border-slate-200 dark:border-slate-800 py-3 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-200 cursor-pointer"
                    >
                      Reset & Retake Drag Match Game
                    </button>
                  )}
                </div>
              )}

              {/* Game type 4: Concept Category Sorting */}
              {currentSection.sortOptions && currentSection.sortOptions.length > 0 && (
                <div className="space-y-6 pt-4" id="sorting-game-activity">
                  <div className="text-xs text-slate-505 bg-slate-50 dark:bg-slate-850 p-3 rounded-xl border border-slate-150 dark:border-slate-800 leading-relaxed font-sans">
                    <strong>Testing Categories Matrix:</strong> Sort the following testing methodologies into their accurate parent categories: <strong>Functional</strong>, <strong>Non-Functional</strong>, or <strong>Structural</strong>.
                  </div>

                  <div className="space-y-4 text-left">
                    {currentSection.sortOptions.map((opt) => {
                      const activeChoice = sortedItems[opt.id];

                      return (
                        <div key={opt.id} className="p-4 rounded-xl border border-slate-150 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                          <div className="space-y-1">
                            <span className="inline-flex rounded bg-blue-105 dark:bg-blue-950 text-blue-700 dark:text-blue-400 font-extrabold px-1.5 py-0.5 text-[9px] uppercase tracking-wide">Method</span>
                            <div className="text-xs font-bold text-slate-900 dark:text-slate-200">{opt.label}</div>
                            <p className="text-[11px] text-slate-500">{opt.description}</p>
                          </div>

                          {/* Category buttons selection grid */}
                          <div className="flex flex-wrap gap-2 shrink-0">
                            {["functional", "non-functional", "structural"].map((cat) => {
                              const isSelected = activeChoice === cat;
                              let btnStyle = "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100";

                              if (isSelected) {
                                if (sortSubmitted) {
                                  btnStyle = opt.category === cat 
                                    ? "bg-emerald-500 border-emerald-505 text-white" 
                                    : "bg-red-500 border-red-505 text-white";
                                } else {
                                  btnStyle = "bg-blue-600 border-blue-600 text-white";
                                }
                              }

                              return (
                                <button
                                  key={cat}
                                  disabled={sortSubmitted}
                                  onClick={() => handleSortItemClick(opt.id, cat)}
                                  className={`px-2.5 py-1.5 rounded-lg border text-[10px] uppercase font-extrabold tracking-tight cursor-pointer transition-all ${btnStyle}`}
                                >
                                  {cat}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {sortMessage && (
                    <div className={`p-3 rounded-xl text-center font-bold text-xs border ${
                      sortMessage.includes("Spot-on") ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 border-emerald-100" : "bg-amber-50 dark:bg-amber-950/20 text-amber-800 dark:text-amber-400 border-amber-100"
                    }`}>
                      {sortMessage}
                    </div>
                  )}

                  <div className="flex gap-4">
                    {!sortSubmitted ? (
                      <button
                        onClick={handleSubmitSortingGame}
                        disabled={currentSection.sortOptions.some(o => !sortedItems[o.id])}
                        className="w-full rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs py-3 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                      >
                        Assess Categorized Alignment
                      </button>
                    ) : (
                      <button
                        onClick={handleResetSortingGame}
                        className="w-full rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-750 dark:text-slate-300 font-bold text-xs py-3 hover:bg-slate-20s transition-all cursor-pointer"
                      >
                        Reset & Try Sorting Again
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 4. Exam Quiz Launcher Tab */}
          {activeContentTab === "quiz" && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-3xs space-y-6 text-left animate-fade-in animate-pulse-slow">
              
              <div className="space-y-1.5 border-b border-slate-100 dark:border-slate-800 pb-4">
                <span className="text-[10px] font-bold text-amber-500 uppercase tracking-widest">Global Module Examination</span>
                <h3 className="font-bold text-slate-900 dark:text-white text-md">Final Syllabus Exam for Module {module.id}</h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs">Test your mastery across all lecturing sections in this course sequence and unlock permanent credentials.</p>
              </div>

              {isModuleFullyCompleted ? (
                <div className="bg-gradient-to-r from-blue-50/70 to-blue-100/30 dark:from-sky-950/20 dark:to-blue-950/15 border border-blue-200 dark:border-blue-900/40 p-6 rounded-2xl space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-md">
                      <Trophy className="h-6 w-6 text-amber-300" />
                    </div>
                    <div>
                      <h4 className="font-sans font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2 flex-wrap">
                        <span>Quiz Assessment Unlocked!</span>
                        {hasTakenQuiz && (
                          <span className="bg-emerald-50 text-emerald-755 dark:bg-emerald-950/20 dark:text-emerald-400 text-[9px] font-bold px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800 uppercase font-sans">
                            Best Score: {bestQuizScore}%
                          </span>
                        )}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-405 mt-0.5">
                        You have studied and approved all lecturing sections. Ready for the test?
                      </p>
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      onClick={() => setIsQuizOpen(true)}
                      className="rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold py-3 px-5 transition-all cursor-pointer shadow-sm flex items-center gap-2"
                    >
                      <Award className="w-4.5 h-4.5" />
                      <span>{hasTakenQuiz ? "Retake Core Module Exam Quiz" : "Start Syllabus Exam Quiz (+150 XP)"}</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="rounded-2xl border border-red-150 dark:border-red-900/30 bg-red-50/10 dark:bg-red-950/15 p-6 space-y-4">
                  <div className="flex items-start gap-3.5">
                    <div className="p-2.5 rounded-xl bg-red-100 dark:bg-red-950/60 text-red-655 dark:text-red-400 shrink-0">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-red-200">Exam Gate Standard Locked</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                        To unlock the certificate quiz, you must study and mark every lecture section in this module as completed. This ensures adequate prep!
                      </p>
                    </div>
                  </div>

                  <div className="pt-2 space-y-2">
                    <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-405 font-bold">
                      <span>Module Track Checklist:</span>
                      <span>{completedSectionsInModule.length} of {module.sections.length} lectures completed</span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                      <div 
                        className="bg-red-500 h-1.5 rounded-full transition-all duration-300" 
                        style={{ width: `${(completedSectionsInModule.length / module.sections.length) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              )}

            </div>
          )}

        </div>

        {/* Right column Section Study Guide info panels */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Module checklist progress */}
          <div className="rounded-2xl border border-slate-150 dark:border-slate-850 bg-white dark:bg-slate-900 p-6 shadow-3xs space-y-4 text-left">
            <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider">Module Study Checklist</h4>
            <div className="space-y-1.5">
              {module.sections.map((sect) => {
                const isActive = activeTab === sect.id;
                const isCompleted = progress.completedSections.includes(sect.id);

                return (
                  <div 
                    key={sect.id} 
                    onClick={() => {
                      setActiveTab(sect.id);
                      setActiveContentTab("theory");
                    }}
                    className={`flex items-center gap-3 p-2 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                      isActive ? "bg-blue-50/50 dark:bg-blue-955/20 text-blue-700 dark:text-blue-400" : "text-slate-650 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-850"
                    }`}
                  >
                    <div className={`shrink-0 rounded-full h-4.5 w-4.5 border flex items-center justify-center text-[10px] ${
                      isCompleted 
                        ? "bg-emerald-500 border-emerald-505 text-white" 
                        : "border-slate-300 bg-white dark:bg-slate-800 text-slate-400"
                    }`}>
                      {isCompleted ? "✓" : ""}
                    </div>
                    <span className="truncate">{sect.title}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick study metrics card */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-950 p-6 text-slate-300 shadow-sm space-y-4 text-left font-sans">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="h-4 w-4 text-amber-400" />
              Tester Mindset advice
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed font-sans font-normal">
              Corporate quality metrics balance logical separation systems ("Is the login approved?") with chaotic failure intercept routines ("What triggers when a user types alphanumeric script code inside input boxes, or submits transaction parameters concurrenly?"). Keep this skeptical approach during manual testing sandboxes.
            </p>
          </div>

        </div>

      </div>

      {/* Reusable Quiz Modal Assessment overlay */}
      <QuizModal
        isOpen={isQuizOpen}
        onClose={() => setIsQuizOpen(false)}
        moduleId={module.id}
        moduleTitle={module.title}
        questions={moduleQuestions}
        progress={progress}
        onUpdateProgress={onUpdateProgress}
      />
    </div>
  );
}

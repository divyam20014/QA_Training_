import React, { useState } from "react";
import { 
  Search, 
  BookOpen, 
  Sparkles, 
  Eye, 
  Clock, 
  ArrowLeft, 
  CheckSquare, 
  Copy, 
  Check, 
  User, 
  Calendar,
  Layers,
  Shield,
  Heart
} from "lucide-react";

interface Article {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  date: string;
  author: string;
  authorRole: string;
  tags: string[];
  content: string;
  codeSnippet?: string;
  codeLanguage?: string;
  interactiveTool?: {
    type: "checklist";
    title: string;
    items: { text: string; completed: boolean }[];
  };
}

export default function TrendsBlog() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTag, setSelectedTag] = useState("All");
  const [activeArticleId, setActiveArticleId] = useState<string | null>(null);
  const [copyingSnippet, setCopyingSnippet] = useState(false);

  // Dynamic interactive tool state for checklists
  const [checklistsState, setChecklistsState] = useState<{ [articleId: string]: boolean[] }>({
    "ai-tools": [false, false, false, false, false],
    "shift-right": [false, false, false, false],
    "accessibility": [false, false, false, false, false]
  });

  const articles: Article[] = [
    {
      id: "ai-tools",
      title: "Top 10 AI-Augmented Software Testing Tools in 2026",
      excerpt: "An in-depth corporate comparison of the leading AI-powered test creation, self-healing element maintenance, and autonomous verification platforms rewriting the QA handbook.",
      category: "AI & Automation",
      readTime: "6 min read",
      date: "June 14, 2026",
      author: "Samantha Croft",
      authorRole: "Principal QA DevOps Architect",
      tags: ["AI testing", "Automation", "Playwright AI", "Self-healing"],
      interactiveTool: {
        type: "checklist",
        title: "AI Test Tool Selection Readiness Checklist",
        items: [
          { text: "Verify that selector weights can fallback to semantic bounds dynamically.", completed: false },
          { text: "Confirm LLM evaluation engines operate on server-side proxy nodes (never exposing local keys).", completed: false },
          { text: "Check compatibility with standard Playwright, Cypress, or Selenium drivers/browsers.", completed: false },
          { text: "Analyze safety flags to avoid hallucinated test boundaries during dynamic flows.", completed: false },
          { text: "Test synthetic mockup inputs generator for non-bias criteria checks.", completed: false }
        ]
      },
      codeLanguage: "javascript",
      codeSnippet: `// Example: Standard 2026 Playwright AI Self-Healing Selector Hook
import { test, expect } from '@playwright/test';

test('Dynamic checkout verification using self-healing semantic selectors', async ({ page }) => {
  await page.goto('/sandbox');

  // Multi-weight AI selector hook. Re-evaluates on layout drift or CSS modifications.
  const submitButton = page.locator('button', { 
    hasText: /Submit Transaction|Confirm Payment/i 
  });
  
  // Guard clause assertion
  await expect(submitButton).toBeVisible({ timeout: 5000 });
  await submitButton.click();
  
  // Validate telemetry confirmation code is registered
  const telemetryToast = page.locator('[data-telemetry-status="success"]');
  await expect(telemetryToast).toContainText('200 OK');
});`,
      content: `The software testing landscape in 2026 is undergoing a monumental paradigm shift. The era of writing rigid, brittle, XPath-heavy selectors is officially drawing to a close. Today, modern QA and SDET teams are utilizing context-aware, autonomous AI testing tools that dynamically maintain tests and heal failed selectors automatically.

### The Problem with Legacy Selectors
In historic agile environments, simple visual modifications, css theme switches, or layout restructures would break dozens of automated regression test scripts. The engineering overhead committed strictly to repairing broken elements cost organizations millions.

### The Rise of Self-Healing & AI-Driven Engines
In 2026, leading technologies like **Playwright AI Extensions**, **Mabl**, and custom **Gemini-backed testing pipelines** analyze the full DOM hierarchy, accessibility tree, and semantic labels of interactive tags. When a button's ID changes from \`#chk-btn-dev\` to \`#checkout-submit-2026\`, the AI engine recognizes the semantic, structural similarity and context automatically, self-healing the selector weight parameters and avoiding execution freezes.

### Top AI QA Tools to Standardize in 2026
1. **Playwright AI Studio**: Direct schema extraction and visual alignment auditing.
2. **Gemini SDK (Testing Engine)**: Evaluates complex user criteria and formats functional suites in real time.
3. **Mabl Autonomous Engine**: Non-coder readable flows with automatic regression assertions.
4. **Fiddler AI & TruLens**: Evaluating system prompts for toxicity filters, hallucinations, and fair bias allocation.
`
    },
    {
      id: "shift-right",
      title: "The Shift-Right & Cloud-Native Chaos Engineering Revolution",
      excerpt: "Discover why testing in production, continuous container telemetry, and Kubernetes chaos simulation loops are now the gold standard for high-performance testing teams.",
      category: "DevOps & Cloud",
      readTime: "8 min read",
      date: "May 29, 2026",
      author: "Marcus Vance",
      authorRole: "Director of Reliability Engineering",
      tags: ["Chaos Mesh", "Shift-Right", "Datadog", "Cloud-Native"],
      interactiveTool: {
        type: "checklist",
        title: "Chaos Engineering Readiness Checklist",
        items: [
          { text: "Confirm microservice routing has graceful fallbacks on localized container crashes.", completed: false },
          { text: "Ensure Prometheus/Datadog monitors trigger real-time alerts under 2000ms latency peaks.", completed: false },
          { text: "Validate circuit breaker pattern triggers to insulate upstream modules during database timeouts.", completed: false },
          { text: "Verify trace telemetry context propagates correctly across active API nodes.", completed: false }
        ]
      },
      codeLanguage: "bash",
      codeSnippet: `# Example: Shell setup for container microservice chaos inject simulation
kubectl apply -f - <<EOF
apiVersion: chaos-mesh.org/v1alpha1
kind: PodChaos
metadata:
  name: container-failure-simulator
  namespace: qa-sandbox
spec:
  action: pod-kill
  mode: fixed
  value: '1'
  selector:
    namespaces:
      - qa-sandbox
    labelSelectors:
      'app': 'payment-gateway'
  scheduler:
    cron: '*/5 * * * *'
EOF`,
      content: `Historically, the testing process was confined inside static pre-production environments. Staging servers were kept under isolation, hoping that production deployment would run matching behaviors. But as cloud-native microservice architectures scale to hundreds of isolated dynamic container pods, staging is no longer a perfect replica of reality.

### Shift-Left is Great, But Shift-Right is Vital
While catching requirements issues early (Shift-Left) remains essential, testing inside the active production container pipeline is now a foundational practice. By employing continuous telemetry gathering, dynamic synthetic user loops, and Canary deployments, engineers immediately uncover latency drops and routing discrepancies.

### Practicing Chaos Engineering
It is no longer enough to wait for an architecture failure to see how your backend behaves. Under 2026 standards, reliability teams introduce programmed, graceful failures directly inside testing pods using Chaos Mesh or AWS FIS (Fault Injection Simulator).

By simulating CPU throttling or localized microservice database connection timeouts, QA teams guarantee that UI apps recover gracefully instead of displaying ugly raw error stacktraces to customers.`
    },
    {
      id: "accessibility",
      title: "A11y & WCAG 3.0: Establishing Pristine Interactive Accessibility",
      excerpt: "Deeply understand semantic HTML structures, dynamic focus outlines, keyboard tab coordination, and ARIA compliant visual structures for modern corporate learning stacks.",
      category: "A11y Standards",
      readTime: "5 min read",
      date: "April 18, 2026",
      author: "Hana Takahashi",
      authorRole: "Chief Accessibility Consultant",
      tags: ["A11y", "WCAG 3.0", "Keyboard Navigation", "Semantic UI"],
      interactiveTool: {
        type: "checklist",
        title: "Pristine A11y Verification Checklist",
        items: [
          { text: "Confirm normal text maintains a minimum brightness contrast of 4.5:1 against the background.", completed: false },
          { text: "Test full keyboard navigation of active lists using only Tab, Shift+Tab, and Enter.", completed: false },
          { text: "Verify interactive elements (buttons, inputs) include intuitive, clear 'aria-label' text parameters.", completed: false },
          { text: "Validate active states possess a robust blue focus ring outlines.", completed: false },
          { text: "Ensure layout uses strictly semantic layout tags (<nav>, <article>, <main>, <header>).", completed: false }
        ]
      },
      codeLanguage: "html",
      codeSnippet: `<!-- Compliant ARIA layout for interactive search cards containing semantic anchors -->
<div 
  id="search-card-01" 
  class="p-4 bg-white border border-slate-200 rounded-xl focus-within:ring-2 focus-within:ring-blue-600 focus-within:outline-hidden"
  role="region" 
  aria-label="Syllabus search result details"
>
  <h4 class="text-sm font-bold text-slate-950 font-sans" id="title-01">Equivalence Separation Methods</h4>
  <p class="text-xs text-slate-500 mt-1">Lecture modules teaching split boundaries constraints.</p>
  
  <button 
    type="button"
    aria-labelledby="title-01 button-label-01"
    id="button-label-01"
    class="mt-3 inline-flex items-center text-xs font-bold text-blue-600 focus:outline-[2px] focus:outline-blue-600 focus:outline-offset-2"
  >
    Launch Interactive Lab
  </button>
</div>`,
      content: `Digital accessibility is no longer secondary—it is an absolute compliance requirement. WCAG 3.0 (Web Content Accessibility Guidelines) outlines core patterns centered around human experience, device independence, and structural cognitive clarity in digital learning layout models.

### Focus Outlines: The Visual Beacon
Many designers disable native element focus outlines because they find them visually distracting. However, for users relying purely on keyboard devices or mouth-sticks to navigate, removing focus outlines makes the system completely unusable. Focus states must always be visible, using highly legible indicators like \`outline: 2px solid #2563EB\` or stylish Tailwind ring markers.

### Keyboard Tab Coordination & Tab Index
Every single functional action—be it opening a slide, playing a presentation, submitting answers, or scrolling a table—**must** be fully navigable via keyboard protocols. Developers must use standard button/input tags and configure appropriate indices to make keyboard navigation fluent.`
    }
  ];

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopyingSnippet(true);
    setTimeout(() => setCopyingSnippet(false), 2000);
  };

  const toggleChecklistItem = (articleId: string, itemIdx: number) => {
    const nextList = [...checklistsState[articleId]];
    nextList[itemIdx] = !nextList[itemIdx];
    setChecklistsState({
      ...checklistsState,
      [articleId]: nextList
    });
  };

  const filteredArticles = articles.filter(art => {
    const matchesSearch = art.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          art.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          art.author.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesTag = selectedTag === "All" || art.tags.includes(selectedTag);
    return matchesSearch && matchesTag;
  });

  // Unique list of tags for quick selection filter
  const allTags = ["All", "AI testing", "Self-healing", "Shift-Right", "Chaos", "A11y", "WCAG 3.0"];

  const activeArticle = articles.find(a => a.id === activeArticleId);

  return (
    <div className="space-y-8 animate-fade-in font-sans" id="blog-room">
      
      {/* Article Detail View Overlay / Fullscreen modal */}
      {activeArticle ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-md space-y-6">
          
          {/* Back button */}
          <button
            onClick={() => setActiveArticleId(null)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-350 rounded-xl transition-all cursor-pointer focus:ring-2 focus:ring-blue-600"
            aria-label="Back to tech articles list"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Journal Articles</span>
          </button>

          <header className="space-y-3.5 border-b border-slate-100 dark:border-slate-800 pb-5">
            <span className="text-[10px] font-extrabold uppercase bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 px-2.5 py-1 rounded border border-blue-100 dark:border-blue-900">
              {activeArticle.category}
            </span>
            <h1 className="text-xl sm:text-3xl font-extrabold text-slate-900 dark:text-white leading-tight tracking-tight">
              {activeArticle.title}
            </h1>
            
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 dark:text-slate-400 font-medium">
              <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
                <div className="h-6 w-6 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center font-bold text-[10px]">
                  {activeArticle.author.split(' ').map(n=>n[0]).join('')}
                </div>
                <span>By {activeArticle.author} ({activeArticle.authorRole})</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="h-3.5 w-3.5" />
                <span>Published {activeArticle.date}</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" />
                <span>{activeArticle.readTime}</span>
              </div>
            </div>
          </header>

          {/* Longform Rich Article Content Body */}
          <div className="text-slate-700 dark:text-slate-250 text-xs sm:text-sm leading-relaxed space-y-4 max-w-none">
            {activeArticle.content.split('\n\n').map((paragraph, pIdx) => {
              if (paragraph.startsWith("### ")) {
                return (
                  <h3 key={pIdx} className="text-base sm:text-lg font-bold text-slate-950 dark:text-slate-100 font-sans tracking-tight pt-3">
                    {paragraph.replace("### ", "")}
                  </h3>
                );
              }
              if (paragraph.startsWith("1. ")) {
                return (
                  <ol key={pIdx} className="list-decimal pl-5 space-y-1.5 my-2 text-xs">
                    {paragraph.split('\n').map((li, lIdx) => (
                      <li key={lIdx}>{li.replace(/^\d+\.\s+/, "")}</li>
                    ))}
                  </ol>
                );
              }
              return <p key={pIdx} className="font-normal">{paragraph}</p>;
            })}
          </div>

          {/* Code sandbox block display */}
          {activeArticle.codeSnippet && (
            <div className="space-y-2 mt-6">
              <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900 text-slate-200 rounded-t-xl border-b border-slate-850">
                <span className="font-mono text-[10px] tracking-wider uppercase">{activeArticle.codeLanguage || "Code Snippet"}</span>
                <button
                  onClick={() => handleCopyCode(activeArticle.codeSnippet || "")}
                  className="p-1 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-[10px] text-white font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                  aria-label="Copy code block to clipboard"
                >
                  {copyingSnippet ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                  <span>{copyingSnippet ? "Copied!" : "Copy Code"}</span>
                </button>
              </div>
              <pre className="p-4 bg-slate-950 overflow-x-auto text-amber-100 rounded-b-xl font-mono text-[11px] leading-relaxed shadow-inner">
                {activeArticle.codeSnippet}
              </pre>
            </div>
          )}

          {/* Interactive Checkbox Tool inside post */}
          {activeArticle.interactiveTool && (
            <div className="p-5 sm:p-6 bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-850 rounded-2xl space-y-4">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-indigo-505 text-indigo-500" />
                <h4 className="text-xs sm:text-sm font-bold text-slate-950 dark:text-white">
                  {activeArticle.interactiveTool.title}
                </h4>
              </div>
              <div className="space-y-2">
                {activeArticle.interactiveTool.items.map((item, itemIdx) => {
                  const isChecked = checklistsState[activeArticle.id]?.[itemIdx] || false;
                  return (
                    <button
                      key={itemIdx}
                      onClick={() => toggleChecklistItem(activeArticle.id, itemIdx)}
                      className="w-full text-left p-3 rounded-xl border border-slate-200 dark:border-slate-850 bg-white dark:bg-slate-900/60 hover:bg-slate-50 dark:hover:bg-slate-850/60 transition-colors flex gap-2.5 items-start cursor-pointer focus:ring-1 focus:ring-indigo-500"
                    >
                      <span className={`h-4.5 w-4.5 rounded-md border flex items-center justify-center shrink-0 text-xs ${
                        isChecked ? "bg-emerald-600 border-emerald-600 text-white" : "border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-850"
                      }`}>
                        {isChecked && <Check className="h-3 w-3" />}
                      </span>
                      <span className={`text-[11.5px] leading-snug font-medium ${isChecked ? "text-slate-400 dark:text-slate-550 line-through" : "text-slate-700 dark:text-slate-300"}`}>
                        {item.text}
                      </span>
                    </button>
                  );
                })}
              </div>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 italic">This is an active evaluation checklist. Progress resets automatically when leaving this view.</p>
            </div>
          )}

        </div>
      ) : (
        <div className="space-y-6">
          
          <div className="flex flex-col gap-1.5">
            <h2 className="text-xl sm:text-2xl font-black text-slate-950 dark:text-slate-50 font-sans tracking-tight">QA Insights Journal (2026 Shift-Right Special)</h2>
            <p className="text-slate-600 dark:text-slate-400 text-xs sm:text-sm font-sans">
              Stay ahead of standard QA processes by mastering self-healing automated test suites, Chaos-injection, and critical Web accessibility (WCAG 3.0) patterns.
            </p>
          </div>

          {/* Search bar and Filters */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 py-1.5 border-b border-slate-200 dark:border-slate-850 pb-4">
            
            {/* Search Input Box */}
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 dark:text-slate-500" />
              <input
                type="text"
                placeholder="Search QA trends and articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-250 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden text-slate-800 dark:text-slate-100 placeholder:text-slate-400"
                aria-label="Filter journal articles"
              />
            </div>

            {/* Dynamic chips tags filters */}
            <div className="flex flex-wrap gap-1.5">
              {allTags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => setSelectedTag(tag)}
                  className={`px-3 py-1.5 rounded-lg border text-[10.5px] font-bold tracking-tight transition-all cursor-pointer ${
                    selectedTag === tag
                      ? "bg-slate-950 dark:bg-white border-slate-950 dark:border-white text-white dark:text-slate-950"
                      : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-550 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-850"
                  }`}
                  aria-label={`Toggle tag ${tag}`}
                >
                  {tag}
                </button>
              ))}
            </div>

          </div>

          {/* Articles grid cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredArticles.length > 0 ? (
              filteredArticles.map((art) => (
                <article 
                  key={art.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl flex flex-col justify-between overflow-hidden hover:shadow-md transition-all group"
                  id={`article-card-${art.id}`}
                >
                  <div className="p-5 flex flex-col gap-3">
                    <div className="flex justify-between items-center text-[10px] font-extrabold uppercase text-slate-400">
                      <span>{art.category}</span>
                      <span className="flex items-center gap-0.5"><Clock className="h-3 w-3" /> {art.readTime}</span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-normal tracking-tight group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                      {art.title}
                    </h3>
                    <p className="text-slate-600 dark:text-slate-400 text-xs leading-normal font-sans line-clamp-3">
                      {art.excerpt}
                    </p>
                  </div>

                  <div className="p-5 pt-0 flex flex-col gap-4">
                    <div className="flex flex-wrap gap-1">
                      {art.tags.slice(0, 3).map((tag, tIdx) => (
                        <span key={tIdx} className="text-[9px] font-bold text-slate-500 bg-slate-100 dark:bg-slate-800 dark:text-slate-450 px-2 py-0.5 rounded-md border border-slate-150 dark:border-transparent">
                          {tag}
                        </span>
                      ))}
                    </div>

                    <button
                      onClick={() => setActiveArticleId(art.id)}
                      className="w-full text-center py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl cursor-pointer transition-all flex items-center justify-center gap-1.5 focus:outline-[2px] focus:outline-blue-600 focus:outline-offset-2"
                      aria-label={`Read article: ${art.title}`}
                    >
                      <BookOpen className="h-4 w-4" />
                      <span>Read Deep Dive Study</span>
                    </button>
                  </div>
                </article>
              ))
            ) : (
              <div className="col-span-full py-16 text-center border border-dashed border-slate-250 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-900 text-slate-400 text-xs flex flex-col gap-2 items-center justify-center">
                <BookOpen className="h-8 w-8 opacity-40 animate-pulse" />
                <span className="font-semibold">No journal entries match your filters.</span>
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
}
